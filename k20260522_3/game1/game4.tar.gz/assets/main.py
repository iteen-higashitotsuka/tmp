# -*- coding: utf-8 -*-
import pygame
import random
import asyncio  # pygbag用の非同期処理モジュール
import urllib.request
import io

# --- 設定 ---
SCREEN_WIDTH = 500
SCREEN_HEIGHT = 700
GRID_SIZE = 8
CELL_SIZE = 40
GRID_MARGIN = (SCREEN_WIDTH - (GRID_SIZE * CELL_SIZE)) // 2
TOP_MARGIN = 80

WHITE = (255, 255, 255)
BLACK = (20, 20, 20)
GRAY = (50, 50, 50)
COLORS = [(255, 50, 50), (50, 255, 50), (50, 100, 255), (255, 200, 0), (200, 50, 255)]

SHAPES = [
    [[1]], [[1, 1]], [[1, 1, 1]], [[1, 1, 1, 1]], [[1, 1, 1, 1, 1]],
    [[1], [1]], [[1], [1], [1]], [[1], [1], [1], [1]], [[1], [1], [1], [1], [1]],
    [[1, 1, 1], [0, 1, 0]], [[0, 1, 0], [1, 1, 1]], [[1, 0], [1, 1], [1, 0]], [[0, 1], [1, 1], [0, 1]],
    [[1, 1], [1, 1]], [[1, 1, 1], [1, 1, 1], [1, 1, 1]], [[1, 1, 1], [1, 0, 0]], [[1, 1, 1], [0, 0, 1]]
]

class Particle:
    def __init__(self, x, y, color):
        self.x, self.y = x, y
        self.color = color
        self.vx = random.uniform(-5, 5)
        self.vy = random.uniform(-5, 5)
        self.lifetime = 255

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.lifetime -= 15

    def draw(self, screen):
        if self.lifetime > 0:
            s = pygame.Surface((4, 4))
            s.set_alpha(self.lifetime)
            s.fill(self.color)
            screen.blit(s, (self.x, self.y))

class Block:
    def __init__(self, shape, x, y):
        self.shape = shape
        self.color = random.choice(COLORS)
        self.spawn_pos = (x, y)
        self.x, self.y = x, y
        self.dragging = False

    def reset_pos(self):
        self.x, self.y = self.spawn_pos
        self.dragging = False

    def draw(self, screen):
        # ドラッグ中なら通常サイズ、手札にあれば0.7倍
        display_size = CELL_SIZE if self.dragging else CELL_SIZE * 0.7
        for r_idx, row in enumerate(self.shape):
            for c_idx, val in enumerate(row):
                if val:
                    pygame.draw.rect(screen, self.color, 
                        (self.x + c_idx * display_size, self.y + r_idx * display_size, display_size - 2, display_size - 2))

def can_place_anywhere(grid, hand_blocks):
    for block in hand_blocks:
        h, w = len(block.shape), len(block.shape[0])
        for r in range(GRID_SIZE - h + 1):
            for c in range(GRID_SIZE - w + 1):
                if all(not (block.shape[ri][ci] and grid[r+ri][c+ci]) for ri in range(h) for ci in range(w)):
                    return True
    return False

# --- メイン（async対応） ---
async def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Block Blast Evolution")
    clock = pygame.time.Clock()

    # --- Web環境用のフォントダウンロード ---
    print("フォントを読み込み中...")
    try:
        font_url = "https://github.com/googlefonts/noto-fonts/raw/main/hinted/ttf/NotoSans/NotoSans-Bold.ttf"
        response = urllib.request.urlopen(font_url)
        font_data = io.BytesIO(response.read())
        font = pygame.font.Font(font_data, 40)
        small_font = pygame.font.Font(font_data, 25)
    except Exception as e:
        print(f"フォント読み込み失敗: {e}")
        font = pygame.font.SysFont("Arial", 40, bold=True)
        small_font = pygame.font.SysFont("Arial", 25, bold=True)

    grid = [[None for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]
    score = 0
    game_over = False
    particles = []
    flash_cells = [] 

    def get_new_blocks():
        # iPadの画面端でもタップしやすいように初期X座標を少し内側に調整 (60 + i*135)
        return [Block(random.choice(SHAPES), 60 + i*135, 550) for i in range(3)]

    hand_blocks = get_new_blocks()
    dragging_block = None
    offset_x, offset_y = 0, 0

    running = True
    while running:
        screen.fill(BLACK)
        
        # グリッド描画
        for r in range(GRID_SIZE):
            for c in range(GRID_SIZE):
                rect = pygame.Rect(GRID_MARGIN + c * CELL_SIZE, TOP_MARGIN + r * CELL_SIZE, CELL_SIZE, CELL_SIZE)
                pygame.draw.rect(screen, GRAY, rect, 1)
                if grid[r][c]:
                    pygame.draw.rect(screen, grid[r][c], rect.inflate(-2, -2))
                
                # 設置時のフラッシュ演出
                for fr, fc, life in flash_cells:
                    if fr == r and fc == c:
                        s = pygame.Surface((CELL_SIZE-2, CELL_SIZE-2))
                        s.fill(WHITE)
                        s.set_alpha(life)
                        screen.blit(s, rect.topleft)

        # フラッシュ演出の更新
        flash_cells = [(r, c, l-30) for r, c, l in flash_cells if l > 0]

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            if game_over:
                # キーボードの R キーか、iPadの画面タップのどちらでもリスタート可能に
                if (event.type == pygame.KEYDOWN and event.key == pygame.K_r) or (event.type == pygame.MOUSEBUTTONDOWN):
                    grid = [[None for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]
                    score = 0
                    game_over = False
                    hand_blocks = get_new_blocks()
                continue

            if event.type == pygame.MOUSEBUTTONDOWN:
                for b in hand_blocks:
                    # 【修正】手札にある時は0.7倍サイズなので、判定用のRectも0.7倍に正確に合わせる
                    d_size = CELL_SIZE * 0.7
                    block_rect = pygame.Rect(b.x, b.y, d_size * len(b.shape[0]), d_size * len(b.shape))
                    if block_rect.collidepoint(event.pos):
                        dragging_block = b
                        b.dragging = True
                        # タッチした位置がブロックの中心〜ズレを維持するようにオフセットを計算
                        offset_x, offset_y = event.pos[0] - b.x, event.pos[1] - b.y
                        break

            elif event.type == pygame.MOUSEBUTTONUP and dragging_block:
                # グリッド上のどこにドロップされたかを計算
                gx, gy = round((dragging_block.x - GRID_MARGIN) / CELL_SIZE), round((dragging_block.y - TOP_MARGIN) / CELL_SIZE)
                
                if 0 <= gx <= GRID_SIZE - len(dragging_block.shape[0]) and 0 <= gy <= GRID_SIZE - len(dragging_block.shape) and \
                   all(not (dragging_block.shape[ri][ci] and grid[gy+ri][gx+ci]) for ri in range(len(dragging_block.shape)) for ci in range(len(dragging_block.shape[0]))):
                    
                    for ri, row in enumerate(dragging_block.shape):
                        for ci, val in enumerate(row):
                            if val:
                                grid[gy+ri][gx+ci] = dragging_block.color
                                flash_cells.append((gy+ri, gx+ci, 200))
                    
                    hand_blocks.remove(dragging_block)
                    rows = [r for r in range(GRID_SIZE) if all(grid[r])]
                    cols = [c for c in range(GRID_SIZE) if all(grid[r][c] for r in range(GRID_SIZE))]
                    
                    # 消去パーティクル
                    for r in rows:
                        for c in range(GRID_SIZE):
                            for _ in range(5): particles.append(Particle(GRID_MARGIN + c*CELL_SIZE + 20, TOP_MARGIN + r*CELL_SIZE + 20, grid[r][c]))
                            grid[r][c] = None
                    for c in cols:
                        for r in range(GRID_SIZE):
                            if grid[r][c]:
                                for _ in range(5): particles.append(Particle(GRID_MARGIN + c*CELL_SIZE + 20, TOP_MARGIN + r*CELL_SIZE + 20, grid[r][c]))
                                grid[r][c] = None
                    
                    score += (len(rows) + len(cols)) * 10
                    if not hand_blocks: hand_blocks = get_new_blocks()
                    if not can_place_anywhere(grid, hand_blocks): game_over = True
                else:
                    # 置けない場所なら手札の元の位置に戻す
                    dragging_block.reset_pos()
                dragging_block.dragging = False
                dragging_block = None

            elif event.type == pygame.MOUSEMOTION and dragging_block:
                # ドラッグ中の移動処理（指の動きに追従）
                dragging_block.x, dragging_block.y = event.pos[0] - offset_x, event.pos[1] - offset_y

        # パーティクル更新・描画
        for p in particles[:]:
            p.update()
            p.draw(screen)
            if p.lifetime <= 0: particles.remove(p)

        # 手札ブロックの描画
        for b in hand_blocks: b.draw(screen)
        
        # スコア・UI表示
        screen.blit(font.render(f"Score: {score}", True, WHITE), (20, 20))
        if game_over:
            # 画面中央付近にゲームオーバーUI
            pygame.draw.rect(screen, (10, 10, 10), (80, 260, 340, 160), border_radius=10)
            pygame.draw.rect(screen, (255, 50, 50), (80, 260, 340, 160), 2, border_radius=10)
            
            go_text = font.render("GAME OVER", True, (255, 50, 50))
            hint_text = small_font.render("Tap Screen to Restart", True, WHITE)
            
            screen.blit(go_text, (SCREEN_WIDTH//2 - go_text.get_width()//2, 290))
            screen.blit(hint_text, (SCREEN_WIDTH//2 - hint_text.get_width()//2, 350))

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)  # pygbagのフリーズ防止に必須の処理
        
    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())