import pygame
import math
import random
import os
import json
import asyncio

# --- Settings ---
WIDTH, HEIGHT = 800, 600
FPS = 60
FOV = 400 

# Filenames
ZOMBIE_IMAGE_FILENAME = "zombie.png"
SKELETON_IMAGE_FILENAME = "skeleton.png" 
BG_IMAGE_FILENAME = "background.jpg"
GUN_IMAGE_FILENAME = "gun.png"
RANKING_FILENAME = "ranking.json"

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
GRAY = (100, 100, 100)
DARK_GRAY = (50, 50, 50)
PURPLE = (128, 0, 128)
CYAN = (0, 255, 255)

# --- Common Functions ---
def load_ranking():
    try:
        if os.path.exists(RANKING_FILENAME):
            with open(RANKING_FILENAME, "r") as f: return json.load(f)
    except:
        pass
    return []

def save_ranking(score):
    ranking = load_ranking()
    ranking.append(score); ranking.sort(reverse=True)
    ranking = ranking[:5]
    try:
        with open(RANKING_FILENAME, "w") as f: json.dump(ranking, f)
    except:
        pass
    return ranking

def project(pos_3d, player_x):
    x, y, z = pos_3d
    rel_x = x - player_x
    if z <= 0.1: z = 0.1
    f = FOV / z
    sx = int(rel_x * f) + WIDTH // 2
    sy = int(y * f) + HEIGHT // 2
    return (sx, sy), f

def load_image(filename):
    try:
        return pygame.image.load(filename).convert_alpha()
    except:
        return None

# --- Effects ---
class Particle:
    def __init__(self, x, y, z, color=RED):
        self.pos = [x, y, z]
        self.vel = [random.uniform(-0.3, 0.3), random.uniform(-0.5, 0), random.uniform(-0.2, 0.2)]
        self.life = 20
        self.color = color
    def update(self):
        for i in range(3): self.pos[i] += self.vel[i]
        self.vel[1] += 0.02; self.life -= 1
    def draw(self, screen, player_x):
        p, f = project(self.pos, player_x)
        if self.life > 0: pygame.draw.circle(screen, self.color, p, max(1, int(f * 0.1)))

class Slash:
    def __init__(self):
        self.life = 10
        self.points = [(WIDTH//2 - 150, HEIGHT//2 + 80), (WIDTH//2 + 150, HEIGHT//2 - 80)]
    def update(self): self.life -= 1
    def draw(self, screen):
        pygame.draw.line(screen, (200, 255, 255), self.points[0], self.points[1], self.life * 3)

# --- Enemy Projectile (Bone) ---
class Bone:
    def __init__(self, x, y, z, target_x):
        self.pos = [x, y, z]
        self.speed = 1.2
        self.vx = (target_x - x) * 0.02
        self.active = True
    def update(self):
        self.pos[2] -= self.speed
        self.pos[0] += self.vx
        self.pos[1] += math.sin(self.pos[2] * 0.5) * 0.05
        if self.pos[2] < 0: self.active = False
    def draw(self, screen, player_x):
        p, f = project(self.pos, player_x)
        size = max(2, int(f * 0.3))
        pygame.draw.rect(screen, WHITE, (p[0]-size, p[1]-size//2, size*2, size))

# --- Player Projectile (Bullet) ---
class Bullet:
    def __init__(self, start_x):
        self.pos = [start_x, 1.5, 2.0]; self.active = True
    def update(self):
        self.pos[2] += 2.5
        if self.pos[2] > 80: self.active = False
    def draw(self, screen, player_x):
        p1, f1 = project(self.pos, player_x)
        p2, _ = project([self.pos[0], self.pos[1], self.pos[2] + 2.0], player_x)
        if f1 > 0: pygame.draw.line(screen, YELLOW, p1, p2, max(1, int(f1*0.2)))

# --- Enemy Class ---
class Enemy:
    def __init__(self, z_img, s_img, stage):
        self.z_img, self.s_img, self.stage = z_img, s_img, stage
        self.reset()
    def reset(self):
        is_skel = random.random() < (0.15 + self.stage * 0.1)
        self.type = "SKELETON" if is_skel else "ZOMBIE"
        self.pos = [random.uniform(-20, 20), 2.5, random.uniform(100, 160)]
        self.shoot_timer = random.randint(60, 180)
        if self.type == "SKELETON":
            self.hp = 2; self.speed = 0.18 + (self.stage * 0.02); self.base_scale = 5.0
        else:
            self.is_enhanced = random.random() < 0.2
            self.hp = 10 if self.is_enhanced else 1
            self.speed = 0.12 + (self.stage * 0.01); self.base_scale = 6.5 if self.is_enhanced else 4.5
        self.max_hp = self.hp
    def update(self, player_x, bones):
        self.pos[2] -= self.speed
        if self.type == "SKELETON" and self.pos[2] > 10:
            self.shoot_timer -= 1
            if self.shoot_timer <= 0:
                bones.append(Bone(self.pos[0], self.pos[1]-1, self.pos[2], player_x))
                self.shoot_timer = random.randint(100, 200) - (self.stage * 10)
        if self.pos[2] < 1:
            dmg = 3 if (self.type=="ZOMBIE" and self.hp > 5) else 1
            self.reset(); return dmg
        return 0
    def draw(self, screen, player_x):
        (sx, sy), f = project(self.pos, player_x)
        if 0 < sy < HEIGHT + 400:
            target_h = int(f * self.base_scale)
            img = self.s_img if self.type == "SKELETON" else self.z_img
            if img:
                img_scaled = pygame.transform.scale(img, (int(target_h * 0.7), target_h))
                screen.blit(img_scaled, img_scaled.get_rect(midbottom=(sx, sy)))
            else:
                color = WHITE if self.type == "SKELETON" else (PURPLE if self.hp > 5 else GREEN)
                pygame.draw.rect(screen, color, (sx - int(target_h*0.3), sy - target_h, int(target_h*0.6), target_h))
            if self.hp > 1:
                bw = int(target_h * 0.6)
                pygame.draw.rect(screen, RED, (sx - bw//2, sy - target_h - 10, bw, 5))
                pygame.draw.rect(screen, GREEN, (sx - bw//2, sy - target_h - 10, int(bw * (self.hp/self.max_hp)), 5))

# --- Main Async Function ---
async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("Arial", 40)
    small_font = pygame.font.SysFont("Arial", 24)
    
    # Asset Loading
    z_img = load_image(ZOMBIE_IMAGE_FILENAME)
    s_img = load_image(SKELETON_IMAGE_FILENAME)
    bg_img = load_image(BG_IMAGE_FILENAME)
    if bg_img:
        bg_img = pygame.transform.scale(bg_img, (WIDTH + 200, HEIGHT))
    gun_img = load_image(GUN_IMAGE_FILENAME)
    if gun_img:
        img_w = gun_img.get_width()
        img_h = gun_img.get_height()
        gun_img = pygame.transform.scale(gun_img, (int(WIDTH*0.4), int(WIDTH*0.4*(img_h/img_w))))

    def reset_game(stage=1, score=0, hp=30):
        return {
            "mode": "PLAYING", "stage": stage, "score": score, "player_hp": hp,
            "player_x": 0, "recoil": 0, "damage_flash": 0, "ammo": 50, "reloading": False,
            "reload_timer": 0, "shoot_cooldown": 0, "attack_boost": 0,
            "enemies": [Enemy(z_img, s_img, stage) for _ in range(5 + stage * 2)],
            "bullets": [], "bones": [], "particles": [], "slashes": [], "weapon": "GUN",
            "msg": f"STAGE {stage}", "msg_timer": 90
        }

    state = reset_game(1)
    lobby_mode = True

    # iPad Touch UI Buttons (Rectangles)
    btn_l = pygame.Rect(10, 480, 90, 110)
    btn_r = pygame.Rect(110, 480, 90, 110)
    btn_fire = pygame.Rect(680, 480, 110, 110)
    btn_wpn = pygame.Rect(680, 360, 110, 100)
    btn_reload = pygame.Rect(560, 480, 110, 110)

    while True:
        if bg_img: screen.blit(bg_img, (-100 - (state["player_x"] * 5), 0))
        else: screen.fill(BLACK)

        mouse_pos = pygame.mouse.get_pos()
        mouse_pressed = pygame.mouse.get_pressed()[0]

        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); return
            if event.type == pygame.KEYDOWN:
                if lobby_mode:
                    if event.key == pygame.K_s: lobby_mode = False; state = reset_game(1)
                elif state["mode"] == "PLAYING":
                    if event.key == pygame.K_r and not state["reloading"] and state["weapon"] == "GUN":
                        state["reloading"] = True; state["reload_timer"] = 90
                    if event.key in [pygame.K_1, pygame.K_q]: state["weapon"] = "GUN"
                    if event.key in [pygame.K_2, pygame.K_e]: state["weapon"] = "SWORD"
                elif state["mode"] == "GAMEOVER":
                    if event.key == pygame.K_r: state = reset_game(1)
                    if event.key == pygame.K_m: lobby_mode = True
            
            # Touch / Mouse Down Events for iPad
            if event.type == pygame.MOUSEBUTTONDOWN:
                if lobby_mode:
                    lobby_mode = False; state = reset_game(1)
                elif state["mode"] == "GAMEOVER":
                    state = reset_game(1)
                elif state["mode"] == "PLAYING":
                    if btn_wpn.collidepoint(mouse_pos):
                        state["weapon"] = "SWORD" if state["weapon"] == "GUN" else "GUN"
                    if btn_reload.collidepoint(mouse_pos) and not state["reloading"] and state["weapon"] == "GUN":
                        state["reloading"] = True; state["reload_timer"] = 90

        if lobby_mode:
            overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA); overlay.fill((0,0,0,180)); screen.blit(overlay, (0,0))
            screen.blit(font.render("ZOMBIE & SKELETON HUNTER", True, YELLOW), (130, 150))
            screen.blit(small_font.render("TAP SCREEN TO START GAME", True, WHITE), (240, 300))
            screen.blit(small_font.render("HP: 30 / NO TIME LIMIT / 5 STAGES", True, CYAN), (210, 350))
        elif state["mode"] == "PLAYING":
            keys = pygame.key.get_pressed()
            
            # Movement Input (Keyboard or Touch Buttons)
            if keys[pygame.K_a] or keys[pygame.K_LEFT] or (mouse_pressed and btn_l.collidepoint(mouse_pos)): 
                state["player_x"] -= 0.5
            if keys[pygame.K_d] or keys[pygame.K_RIGHT] or (mouse_pressed and btn_r.collidepoint(mouse_pos)): 
                state["player_x"] += 0.5

            if state["shoot_cooldown"] > 0: state["shoot_cooldown"] -= 1
            if state["attack_boost"] > 0: state["attack_boost"] -= 1

            # Action Input (Keyboard or Touch Fire Button)
            is_firing = keys[pygame.K_SPACE] or (mouse_pressed and btn_fire.collidepoint(mouse_pos))
            if is_firing and state["shoot_cooldown"] <= 0:
                if state["weapon"] == "GUN":
                    if not state["reloading"]:
                        if state["ammo"] > 0:
                            state["bullets"].append(Bullet(state["player_x"]))
                            state["ammo"] -= 1; state["recoil"] = 20
                            state["shoot_cooldown"] = 5 if state["attack_boost"] > 0 else 12
                        else:
                            state["reloading"] = True; state["reload_timer"] = 90
                elif state["weapon"] == "SWORD":
                    state["slashes"].append(Slash()); state["recoil"] = 40
                    state["shoot_cooldown"] = 20
                    for e in state["enemies"]:
                        if abs(state["player_x"] - e.pos[0]) < 7 and e.pos[2] < 30:
                            e.hp -= 3
                            for _ in range(5): state["particles"].append(Particle(e.pos[0], 1, e.pos[2], CYAN))
                            if e.hp <= 0:
                                state["score"] += 2 if e.type == "SKELETON" else 1
                                e.reset()

            # Stage Up Check
            target = [0, 15, 35, 65, 100, 150][state["stage"]]
            if state["score"] >= target and state["stage"] < 5:
                state = reset_game(state["stage"] + 1, state["score"], state["player_hp"])

            # Reload Processing
            if state["reloading"]:
                state["reload_timer"] -= 1
                if state["reload_timer"] <= 0: state["ammo"] = 50; state["reloading"] = False
            state["recoil"] = max(0, state["recoil"] - 3)
            
            # Object Updates
            for b in state["bullets"][:]:
                b.update()
                if not b.active: state["bullets"].remove(b)
            
            for bone in state["bones"][:]:
                bone.update()
                if bone.pos[2] < 1:
                    if abs(bone.pos[0] - state["player_x"]) < 4:
                        state["player_hp"] -= 1; state["damage_flash"] = 10
                    state["bones"].remove(bone)
                elif not bone.active: state["bones"].remove(bone)

            for s in state["slashes"][:]:
                s.update()
                if s.life <= 0: state["slashes"].remove(s)
            
            for p in state["particles"][:]:
                p.update()
                if p.life <= 0: state["particles"].remove(p)

            for e in state["enemies"]:
                dmg = e.update(state["player_x"], state["bones"])
                if dmg:
                    state["player_hp"] -= dmg; state["damage_flash"] = 15
                for b in state["bullets"]:
                    if b.active and abs(b.pos[0]-e.pos[0]) < 2.5 and abs(b.pos[2]-e.pos[2]) < 2:
                        b.active = False; e.hp -= 1
                        for _ in range(3): state["particles"].append(Particle(e.pos[0], 1, e.pos[2], YELLOW))
                        if e.hp <= 0:
                            state["score"] += 2 if e.type == "SKELETON" else 1
                            e.reset()

            if state["player_hp"] <= 0: state["mode"] = "GAMEOVER"; state["msg"] = "YOU DIED..."

            # 3D Render
            for e in sorted(state["enemies"], key=lambda x: x.pos[2], reverse=True): e.draw(screen, state["player_x"])
            for b in state["bullets"]: b.draw(screen, state["player_x"])
            for bone in state["bones"]: bone.draw(screen, state["player_x"])
            for s in state["slashes"]: s.draw(screen)
            for p in state["particles"]: p.draw(screen, state["player_x"])
            
            if state["damage_flash"] > 0:
                f = pygame.Surface((WIDTH, HEIGHT)); f.fill(RED); f.set_alpha(100); screen.blit(f, (0,0))
                state["damage_flash"] -= 1

            # Center Crosshair
            pygame.draw.circle(screen, WHITE, (WIDTH//2, HEIGHT//2), 20, 1)
            
            # Weapon Render
            gx, gy = WIDTH//2, HEIGHT + state["recoil"]
            if state["weapon"] == "GUN":
                if gun_img: screen.blit(gun_img, gun_img.get_rect(midbottom=(gx, gy)))
                else: pygame.draw.rect(screen, GRAY, (gx-15, gy-280, 30, 280))
            else:
                pygame.draw.rect(screen, CYAN, (gx-10, gy-280, 20, 280))
            
            # --- iPad Touch UI Drawing ---
            pygame.draw.rect(screen, DARK_GRAY, btn_l); screen.blit(font.render("<", True, WHITE), (45, 510))
            pygame.draw.rect(screen, DARK_GRAY, btn_r); screen.blit(font.render(">", True, WHITE), (145, 510))
            pygame.draw.rect(screen, RED, btn_fire); screen.blit(small_font.render("FIRE", True, WHITE), (715, 520))
            pygame.draw.rect(screen, CYAN, btn_wpn); screen.blit(small_font.render("WEAPON", True, BLACK), (695, 395))
            if state["weapon"] == "GUN":
                pygame.draw.rect(screen, YELLOW, btn_reload); screen.blit(small_font.render("RELOAD", True, BLACK), (575, 520))

            # Status HUD
            screen.blit(small_font.render(f"STAGE: {state['stage']}   SCORE: {state['score']}", True, WHITE), (20, 20))
            hp_col = GREEN if state["player_hp"] > 10 else RED
            screen.blit(font.render(f"HP: {state['player_hp']}", True, hp_col), (20, 50))
            if state["weapon"] == "GUN":
                screen.blit(small_font.render(f"AMMO: {state['ammo']}", True, YELLOW), (20, 100))
            
            if state["reloading"]: 
                screen.blit(font.render("RELOADING...", True, RED), (WIDTH//2-110, HEIGHT//2+100))

            if state["msg_timer"] > 0:
                m_txt = font.render(state["msg"], True, YELLOW)
                screen.blit(m_txt, m_txt.get_rect(center=(WIDTH//2, HEIGHT//2-100)))
                state["msg_timer"] -= 1

        elif state["mode"] == "GAMEOVER":
            overlay = pygame.Surface((WIDTH, HEIGHT)); overlay.fill(BLACK); overlay.set_alpha(200); screen.blit(overlay, (0, 0))
            screen.blit(font.render(state["msg"], True, RED), (WIDTH//2-100, 200))
            screen.blit(small_font.render(f"FINAL SCORE: {state['score']}", True, WHITE), (WIDTH//2-80, 300))
            screen.blit(small_font.render("TAP TO RETURN TO LOBBY", True, CYAN), (WIDTH//2-140, 420))

        pygame.display.flip()
        await asyncio.sleep(0) # Required for pygbag/HTML5 execution
        clock.tick(FPS)

if __name__ == "__main__":
    asyncio.run(main())