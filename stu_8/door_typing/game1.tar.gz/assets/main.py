import pygame
import sys
import random
import math
import array
import asyncio  # 追加: pygbagで非同期処理を行うためのモジュール

# Pygameの初期化とオーディオの初期化
pygame.init()
try:
    pygame.mixer.init()
    audio_enabled = True
except:
    audio_enabled = False

# 画面設定
WIDTH, HEIGHT = 800, 600
FPS = 60  # 前回の定義漏れを修正
screen = pygame.display.set_mode((WIDTH, HEIGHT))
# 画面を揺らすための仮想的な描画サーフェス
render_surface = pygame.Surface((WIDTH, HEIGHT))

pygame.display.set_caption("ドア開けタイピング！ - タブレット＆Web対応版")
clock = pygame.time.Clock()

# 色の定義
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BROWN = (139, 69, 19)
DARK_BROWN = (80, 40, 10)
GOLD = (255, 215, 0)
RED = (255, 50, 50)
GREEN = (50, 255, 50)
GRAY = (100, 100, 100)
LIGHT_GRAY = (180, 180, 180)

# --- フォント設定 (指定されたTTFフォントファイルを直接読み込む) ---
def get_safe_font(size):
    try:
        # 同じディレクトリにあるフォントファイルを読み込む
        return pygame.font.Font("NotoSansJP-Black.ttf", size)
    except:
        # 万が一ファイルが見つからない場合のフォールバック
        return pygame.font.Font(None, size)

font_large = get_safe_font(80)
font_medium = get_safe_font(42)
font_small = get_safe_font(28)

# --- 画面上のキーボード設定 (スマホ/タブレット用) ---
# QWERTY配列の定義
KEYBOARD_LAYOUT = [
    ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
    ["A", "S", "D", "F", "G", "H", "J", "K", "L"],
    ["Z", "X", "C", "V", "B", "N", "M"]
]

# キーの大きさと配置計算
KEY_WIDTH, KEY_HEIGHT = 54, 50
KEY_MARGIN = 6
START_Y = 380

virtual_keys = [] # (pygame.Rect, アルファベットの文字) のリスト
for row_idx, row in enumerate(KEYBOARD_LAYOUT):
    # 行ごとに中央寄せするための初期X座標を計算
    row_width = len(row) * KEY_WIDTH + (len(row) - 1) * KEY_MARGIN
    start_x = (WIDTH - row_width) // 2
    for col_idx, char in enumerate(row):
        kx = start_x + col_idx * (KEY_WIDTH + KEY_MARGIN)
        ky = START_Y + row_idx * (KEY_HEIGHT + KEY_MARGIN)
        virtual_keys.append((pygame.Rect(kx, ky, KEY_WIDTH, KEY_HEIGHT), char))

# スペースキー用のRect (タイトル画面やリザルト画面での兼用)
space_key_rect = pygame.Rect((WIDTH - 300) // 2, START_Y + 3 * (KEY_HEIGHT + KEY_MARGIN), 300, 45)


# --- 効果音の作成（オーディオが有効な場合のみ） ---
def create_sound(freq, duration, wave_type="sine"):
    if not audio_enabled: return None
    sample_rate = 44100
    num_samples = int(sample_rate * duration)
    buf = array.array('h', [0] * num_samples)
    for i in range(num_samples):
        t = float(i) / sample_rate
        if wave_type == "sine":
            v = math.sin(2.0 * math.pi * freq * t)
        elif wave_type == "square":
            v = 1.0 if math.sin(2.0 * math.pi * freq * t) > 0 else -1.0
        buf[i] = int(v * 32767 * 0.3)
    try:
        return pygame.mixer.Sound(buffer=buf)
    except:
        return None

sound_ok = create_sound(523.25, 0.1)      # ド (成功)
sound_miss = create_sound(130.81, 0.2, "square") # 低いド (失敗)
sound_open = create_sound(880.00, 0.15)    # ラ (ドア開く)

def play_sound(snd):
    if audio_enabled and snd:
        try: snd.play()
        except: pass

# --- 単語リスト ---
WORDS = ["APPLE", "BANANA", "CHERRY", "DIGITAL", "ENERGY", "FUTURE", "GALAXY", "HONEY", "INDEX", "JACKET"]

# --- 状態管理 ---
# state: "TITLE", "PLAYING", "RESULT"
state = "TITLE"
tablet_mode = False  # タブレット/スマホモードのフラグ

# タイトル画面のボタンRect
btn_mode_toggle = pygame.Rect((WIDTH - 360) // 2, 310, 360, 60)

# ゲーム変数
score = 0
miss_count = 0
time_limit = 30.0 # 30秒
time_left = time_limit

current_word = ""
typed_index = 0

# 演出用変数
door_open_ratio = 0.0  # 0.0(閉) から 1.0(全開)
door_state = "CLOSED"  # "CLOSED", "OPENING", "WAITING", "CLOSING"
door_timer = 0

shake_intensity = 0
shake_duration = 0

# 単語とドアのリセット関数
def next_door():
    global current_word, typed_index, door_open_ratio, door_state, door_timer
    current_word = random.choice(WORDS)
    typed_index = 0
    door_open_ratio = 0.0
    door_state = "CLOSED"
    door_timer = 0

# 画面揺らし関数の定義
def trigger_shake(intensity, duration):
    global shake_intensity, shake_duration
    shake_intensity = intensity
    shake_duration = duration

# --- メインループ (pygbag用に非同期関数化) ---
async def main():
    global state, tablet_mode, score, miss_count, time_left, current_word, typed_index
    global door_open_ratio, door_state, door_timer, shake_intensity, shake_duration

    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0  # 秒単位の経過時間
        
        simulated_key = None  # タッチパネルで押されたキーを格納する変数

        # --- イベント処理 ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                
            # [マウス/タッチの判定]
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                pos = event.pos
                
                # タイトル画面でのモード切替ボタン
                if state == "TITLE" and btn_mode_toggle.collidepoint(pos):
                    tablet_mode = not tablet_mode
                    play_sound(sound_ok)
                
                # タブレットモード時の画面上キーボード判定
                elif tablet_mode:
                    # 通常アルファベットキーの判定
                    for rect, char in virtual_keys:
                        if rect.collidepoint(pos):
                            simulated_key = char
                            break
                    # スペースキーの判定
                    if space_key_rect.collidepoint(pos):
                        simulated_key = "SPACE"

            # [物理キーボード入力の判定]
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                
                if state == "TITLE" or state == "RESULT":
                    if event.key == pygame.K_SPACE:
                        simulated_key = "SPACE"
                elif state == "PLAYING":
                    # 押されたキーの文字を取得
                    key_name = pygame.key.name(event.key).upper()
                    if len(key_name) == 1 and "A" <= key_name <= "Z":
                        simulated_key = key_name

        # --- ロジックの処理 ---
        if simulated_key == "SPACE":
            if state == "TITLE":
                score = 0
                miss_count = 0
                time_left = time_limit
                next_door()
                state = "PLAYING"
            elif state == "RESULT":
                state = "TITLE"

        elif state == "PLAYING":
            # タイマー減少
            time_left -= dt
            if time_left <= 0:
                time_left = 0
                state = "RESULT"

            # 演出タイマー進行
            if door_timer > 0:
                door_timer -= dt

            # ドアの自動開閉アニメーション
            if door_state == "OPENING":
                door_open_ratio += dt * 5.0  # 高速で開く
                if door_open_ratio >= 1.0:
                    door_open_ratio = 1.0
                    door_state = "WAITING"
                    door_timer = 0.3  # 開いたまま待つ時間
            elif door_state == "WAITING":
                if door_timer <= 0:
                    door_state = "CLOSING"
            elif door_state == "CLOSING":
                door_open_ratio -= dt * 4.0  # 閉じる
                if door_open_ratio <= 0.0:
                    door_open_ratio = 0.0
                    next_door() # 完全に閉じたら次の問題へ

            # タイピング文字が入力された場合
            if simulated_key and "A" <= simulated_key <= "Z" and door_state == "CLOSED":
                target_char = current_word[typed_index]
                if simulated_key == target_char:
                    # タイピング成功
                    typed_index += 1
                    score += 10
                    play_sound(sound_ok)
                    
                    # 単語をすべて打ち終えたらドアを開ける
                    if typed_index >= len(current_word):
                        door_state = "OPENING"
                        play_sound(sound_open)
                else:
                    # タイピング失敗
                    miss_count += 1
                    score = max(0, score - 5)  # ペナルティ
                    play_sound(sound_miss)
                    trigger_shake(8, 0.15)     # 画面を激しく揺らす

        # --- 描画処理 ---
        render_surface.fill(BLACK)

        if state == "TITLE":
            title_text = font_large.render("DOOR OPENER", True, GOLD)
            recommend_text = font_small.render("※キーボード操作推奨", True, RED)
            prompt_text = font_small.render("Press SPACE or Tap below to Start", True, WHITE)
            
            mode_str = f"モード: {'タブレット/スマホ' if tablet_mode else 'PCキーボード'}"
            mode_text = font_medium.render(mode_str, True, WHITE)
            
            render_surface.blit(title_text, (WIDTH//2 - title_text.get_width()//2, 100))
            render_surface.blit(recommend_text, (WIDTH//2 - recommend_text.get_width()//2, 190))
            render_surface.blit(prompt_text, (WIDTH//2 - prompt_text.get_width()//2, 240))
            
            # モード切替ボタンの描画
            pygame.draw.rect(render_surface, DARK_BROWN, btn_mode_toggle, border_radius=8)
            pygame.draw.rect(render_surface, BROWN, btn_mode_toggle, 3, border_radius=8)
            render_surface.blit(mode_text, (WIDTH//2 - mode_text.get_width()//2, 320))
            
            # タブレットモード時はタイトルでもスペースボタンを画面に表示
            if tablet_mode:
                pygame.draw.rect(render_surface, GRAY, space_key_rect, border_radius=6)
                stxt = font_small.render("START (SPACE)", True, WHITE)
                render_surface.blit(stxt, stxt.get_rect(center=space_key_rect.center))

        elif state == "PLAYING":
            # 背景の壁を描画
            pygame.draw.rect(render_surface, DARK_BROWN, (100, 100, 600, 400))
            
            # ドアの描画（左右に分割して開く演出）
            door_w = 150
            door_h = 300
            left_door_x = 250 - (door_w * door_open_ratio)
            right_door_x = 400 + (door_w * door_open_ratio)
            door_y = 200
            
            # 左の扉
            pygame.draw.rect(render_surface, BROWN, (left_door_x, door_y, door_w, door_h))
            pygame.draw.rect(render_surface, BLACK, (left_door_x, door_y, door_w, door_h), 4)
            pygame.draw.circle(render_surface, GOLD, (int(left_door_x + door_w - 15), int(door_y + door_h//2)), 8)
            
            # 右の扉
            pygame.draw.rect(render_surface, BROWN, (right_door_x, door_y, door_w, door_h))
            pygame.draw.rect(render_surface, BLACK, (right_door_x, door_y, door_w, door_h), 4)
            pygame.draw.circle(render_surface, GOLD, (int(right_door_x + 15), int(door_y + door_h//2)), 8)

            # ドアの奥の景色（開いているときに見える色）
            if door_open_ratio > 0.1:
                inner_w = int(door_w * 2 * door_open_ratio)
                pygame.draw.rect(render_surface, GREEN, (WIDTH//2 - inner_w//2, door_y, inner_w, door_h))

            # タイピング文字のレイアウト描画（文字ごとに色を変える）
            if door_state == "CLOSED":
                start_x = WIDTH // 2 - (len(current_word) * 40) // 2  # 中央揃えの幅を調整
                for i, char in enumerate(current_word):
                    if i < typed_index:
                        color = GREEN
                    elif i == typed_index:
                        color = GOLD
                    else:
                        color = WHITE
                    char_surface = font_large.render(char, True, color)
                    render_surface.blit(char_surface, (start_x + i * 55, 230))

            # 上部UI情報
            score_text = font_small.render(f"SCORE: {score}", True, WHITE)
            miss_text = font_small.render(f"MISS: {miss_count}", True, RED)
            time_text = font_small.render(f"TIME: {time_left:.1f}s", True, WHITE)
            
            # UI背景
            pygame.draw.rect(render_surface, BLACK, (10, 10, 150, 40))
            pygame.draw.rect(render_surface, BLACK, (180, 10, 130, 40))
            pygame.draw.rect(render_surface, BLACK, (WIDTH - 160, 10, 150, 40))
            
            render_surface.blit(score_text, (20, 18))
            render_surface.blit(miss_text, (190, 18))
            render_surface.blit(time_text, (WIDTH - 150, 18))

            # タブレットモード時のバーチャルキーボード描画
            if tablet_mode:
                for rect, char in virtual_keys:
                    # 現在打つべき文字のキーを少し強調
                    is_target = (door_state == "CLOSED" and char == current_word[typed_index])
                    k_col = GOLD if is_target else GRAY
                    pygame.draw.rect(render_surface, k_col, rect, border_radius=6)
                    
                    txt = font_small.render(char, True, BLACK if is_target else WHITE)
                    render_surface.blit(txt, txt.get_rect(center=rect.center))

        elif state == "RESULT":
            finish_text = font_large.render("TIME UP!", True, RED)
            result_text = font_large.render(f"TOTAL SCORE: {score}", True, GOLD)
            total_miss_text = font_medium.render(f"Total Misses: {miss_count}", True, WHITE)
            prompt_text = font_small.render("Press SPACE or Tap below to play again", True, WHITE)
            
            render_surface.blit(finish_text, (WIDTH//2 - finish_text.get_width()//2, 100))
            render_surface.blit(result_text, (WIDTH//2 - result_text.get_width()//2, 230))
            render_surface.blit(total_miss_text, (WIDTH//2 - total_miss_text.get_width()//2, 330))
            render_surface.blit(prompt_text, (WIDTH//2 - prompt_text.get_width()//2, 430))
            
            if tablet_mode:
                pygame.draw.rect(render_surface, GRAY, space_key_rect, border_radius=6)
                stxt = font_small.render("RETRY (SPACE)", True, WHITE)
                render_surface.blit(stxt, stxt.get_rect(center=space_key_rect.center))

        # --- シェイク（画面揺れ）演出の適用 ---
        offset_x = 0
        offset_y = 0
        if shake_duration > 0:
            shake_duration -= dt
            offset_x = random.randint(-shake_intensity, shake_intensity)
            offset_y = random.randint(-shake_intensity, shake_intensity)
        else:
            shake_intensity = 0

        # メイン画面へ最終出力
        screen.fill(BLACK)
        screen.blit(render_surface, (offset_x, offset_y))
        pygame.display.flip()
        
        await asyncio.sleep(0) # ブラウザのハングアップを防ぐ必須コード

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    asyncio.run(main())