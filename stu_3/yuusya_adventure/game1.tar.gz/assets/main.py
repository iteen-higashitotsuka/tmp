import pygame
import random
import math
import sys
import asyncio  # 追加: pygbagでの非同期処理用

# 初期化
pygame.init()

# 画面設定
WIDTH = 800
# iPadのタッチ用UI（Dパッドやボタン類）を下部に配置するため、画面高さを拡張
GAME_HEIGHT = 600
UI_PAD_HEIGHT = 160
HEIGHT = GAME_HEIGHT + UI_PAD_HEIGHT  # 600 + 160 = 760 px

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("勇者の大冒険 〜ハードモード・タブレット＆Web対応版〜")

# 色
BLACK, WHITE = (0, 0, 0), (255, 255, 255)
RED, GOLD, SILVER = (200, 50, 50), (255, 215, 0), (192, 192, 192)
BROWN = (139, 69, 19)
PAD_BG_COLOR = (40, 40, 40)
PAD_BTN_COLOR = (80, 80, 80)

clock = pygame.time.Clock()
FPS = 60

# --- フォント設定 (pygbag環境のブラウザ文字化け・エラー対策) ---
def get_safe_font(size):
    # ブラウザ環境でもロードされやすい安全な日本語フォント候補
    font_names = ['notosanscjkjp', 'notosansjapanese', 'meiryo', 'yugothic', 'msgothic']
    available_fonts = pygame.font.get_fonts()
    for f in font_names:
        if f in available_fonts:
            return pygame.font.SysFont(f, size)
    return pygame.font.Font("NotoSansJP-Black.ttf", size)

font = get_safe_font(28)
small_font = get_safe_font(22)
large_font = get_safe_font(40)

# --- iPad用 タッチ操作ボタンのRect配置 ---
# 左側：移動用十字Dパッド
pad_cx, pad_cy = 110, GAME_HEIGHT + 80
B_SIZE = 45
rect_up    = pygame.Rect(pad_cx - B_SIZE//2, pad_cy - B_SIZE * 1.5, B_SIZE, B_SIZE)
rect_down  = pygame.Rect(pad_cx - B_SIZE//2, pad_cy + B_SIZE * 0.5, B_SIZE, B_SIZE)
rect_left  = pygame.Rect(pad_cx - B_SIZE * 1.5, pad_cy - B_SIZE//2, B_SIZE, B_SIZE)
rect_right = pygame.Rect(pad_cx + B_SIZE * 0.5, pad_cy - B_SIZE//2, B_SIZE, B_SIZE)

# 右側：アクションボタン（攻撃・会話進め・ショップ）
rect_attack = pygame.Rect(WIDTH - 150, GAME_HEIGHT + 35, 110, 90)  # [SPACE] / [ENTER] 兼用メインボタン
rect_shop1  = pygame.Rect(WIDTH - 420, GAME_HEIGHT + 45, 110, 70)  # ショップ用 [1] ボタン
rect_shop2  = pygame.Rect(WIDTH - 290, GAME_HEIGHT + 45, 110, 70)  # ショップ用 [2] ボタン


# --- リアル風背景描画 ---
def draw_background(surface, bg_type):
    if bg_type == "village":
        surface.fill((90, 160, 90))
        for x in range(0, WIDTH, 20):
            for y in range(0, GAME_HEIGHT, 20):
                if (x//20 + y//20) % 2 == 0: pygame.draw.rect(surface, (80, 150, 80), (x, y, 20, 20))
    elif bg_type == "plains":
        surface.fill((120, 180, 70))
        for _ in range(50):
            pygame.draw.ellipse(surface, (100, 160, 60), (random.randint(0, WIDTH), random.randint(0, GAME_HEIGHT), 40, 15))
    elif bg_type == "forest":
        surface.fill((40, 80, 40))
        for x in range(0, WIDTH, 60):
            for y in range(0, GAME_HEIGHT, 60):
                pygame.draw.circle(surface, (30, 65, 30), (x+30, y+30), 25)
    elif bg_type == "cave":
        surface.fill((50, 50, 60))
        for _ in range(100):
            pygame.draw.polygon(surface, (40, 40, 50), [(random.randint(0, WIDTH), random.randint(0, GAME_HEIGHT)) for _ in range(3)])
    elif bg_type == "lava_cave": 
        surface.fill((80, 30, 20))
        for _ in range(60):
            pygame.draw.ellipse(surface, (200, 80, 0), (random.randint(0, WIDTH), random.randint(0, GAME_HEIGHT), 50, 20))
    elif bg_type == "snow_mountain": 
        surface.fill((220, 230, 240))
        for x in range(0, WIDTH, 50):
            for y in range(0, GAME_HEIGHT, 50):
                pygame.draw.polygon(surface, (200, 210, 220), [(x, y+20), (x+25, y), (x+50, y+20)])
    elif bg_type == "mountain":
        surface.fill((110, 90, 70))
        for x in range(0, WIDTH, 40):
            for y in range(0, GAME_HEIGHT, 40):
                pygame.draw.rect(surface, (95, 75, 55), (x, y, 38, 38), border_radius=4)
    elif bg_type == "castle_gate":
        surface.fill((80, 80, 90))
        for x in range(0, WIDTH, 50):
            for y in range(0, GAME_HEIGHT, 25):
                offset = 25 if (y//25)%2 == 0 else 0
                pygame.draw.rect(surface, (70, 70, 80), (x - offset, y, 48, 23))
    elif bg_type == "hallway":
        surface.fill((60, 20, 30))
        pygame.draw.rect(surface, (120, 30, 40), (WIDTH//2 - 100, 0, 200, GAME_HEIGHT))
    elif bg_type == "throne":
        surface.fill((40, 10, 40))
        pygame.draw.rect(surface, (150, 20, 20), (WIDTH//2 - 120, 0, 240, GAME_HEIGHT))
        pygame.draw.polygon(surface, GOLD, [(WIDTH//2-150, 0), (WIDTH//2-120, GAME_HEIGHT), (WIDTH//2+120, GAME_HEIGHT), (WIDTH//2+150, 0)], 5)

# --- クラス定義 ---
class Player:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, 30, 45)
        self.speed = 5.5 
        self.max_hp = 5
        self.hp = self.max_hp
        self.coins = 0
        self.weapon_level = 1
        self.invincible = 0
        self.dir = "DOWN"
        self.attack_timer = 0
        self.attack_cooldown = 0
        self.sword_rect = None

    def get_damage(self):
        return [1, 2, 4, 8][self.weapon_level - 1]

    def get_weapon_color(self):
        return [(200, 200, 200), (150, 150, 255), GOLD, (255, 100, 100)][self.weapon_level - 1]

    def move_virtual(self, vkeys):
        """物理キーとバーチャルキー双方に対応した移動・攻撃ロジック"""
        if self.invincible > 0: self.invincible -= 1
        if self.attack_cooldown > 0: self.attack_cooldown -= 1

        if self.attack_timer > 0:
            self.attack_timer -= 1
        else:
            self.sword_rect = None
            dx, dy = 0, 0
            if vkeys["LEFT"]:  dx, self.dir = -self.speed, "LEFT"
            if vkeys["RIGHT"]: dx, self.dir = self.speed, "RIGHT"
            if vkeys["UP"]:    dy, self.dir = -self.speed, "UP"
            if vkeys["DOWN"]:  dy, self.dir = self.speed, "DOWN"
            self.rect.x = max(0, min(WIDTH - self.rect.width, self.rect.x + dx))
            self.rect.y = max(0, min(GAME_HEIGHT - 150 - self.rect.height, self.rect.y + dy))

            if vkeys["ATTACK"] and self.attack_cooldown == 0:
                self.attack_timer = 10     
                self.attack_cooldown = 20  
                sw_size = 50 + (self.weapon_level * 10) 
                
                if self.dir == "LEFT":  self.sword_rect = pygame.Rect(self.rect.left - sw_size, self.rect.centery - sw_size//2, sw_size, sw_size)
                if self.dir == "RIGHT": self.sword_rect = pygame.Rect(self.rect.right, self.rect.centery - sw_size//2, sw_size, sw_size)
                if self.dir == "UP":    self.sword_rect = pygame.Rect(self.rect.centerx - sw_size//2, self.rect.top - sw_size, sw_size, sw_size)
                if self.dir == "DOWN":  self.sword_rect = pygame.Rect(self.rect.centerx - sw_size//2, self.rect.bottom, sw_size, sw_size)

    def draw(self, surface):
        if self.invincible > 0 and self.invincible % 10 < 5: return 

        pygame.draw.ellipse(surface, (0,0,0,100), (self.rect.x, self.rect.bottom - 5, self.rect.width, 10))
        pygame.draw.rect(surface, (40, 80, 180), self.rect, border_radius=6)
        pygame.draw.circle(surface, (255, 224, 189), (self.rect.centerx, self.rect.top - 5), 14)
        pygame.draw.polygon(surface, (200, 200, 200), [(self.rect.left-2, self.rect.top-5), (self.rect.right+2, self.rect.top-5), (self.rect.centerx, self.rect.top-20)])
        
        wx, wy = self.rect.centerx, self.rect.centery
        w_color = self.get_weapon_color()
        if self.attack_timer > 0:
            sz = 40 + (self.weapon_level * 5)
            if self.dir == "RIGHT": pygame.draw.polygon(surface, w_color, [(wx, wy), (wx+sz, wy-15), (wx+sz+10, wy), (wx+sz, wy+15)])
            elif self.dir == "LEFT": pygame.draw.polygon(surface, w_color, [(wx, wy), (wx-sz, wy-15), (wx-sz-10, wy), (wx-sz, wy+15)])
            elif self.dir == "UP": pygame.draw.polygon(surface, w_color, [(wx, wy), (wx-15, wy-sz), (wx, wy-sz-10), (wx+15, wy-sz)])
            elif self.dir == "DOWN": pygame.draw.polygon(surface, w_color, [(wx, wy), (wx-15, wy+sz), (wx, wy+sz+10), (wx+15, wy+sz)])
        else:
            pygame.draw.rect(surface, w_color, (self.rect.right, self.rect.centery, 6, 25))
            pygame.draw.rect(surface, BROWN, (self.rect.right - 2, self.rect.centery + 10, 10, 4))

class Enemy:
    def __init__(self, x, y, e_type):
        self.type = e_type
        self.warp_timer = 0
        
        stats = {
            "slime":      {"w":30, "h":25, "hp":3,   "spd":1.8, "coin":10, "col":(50,150,255)},
            "wolf":       {"w":40, "h":30, "hp":4,   "spd":3.2, "coin":15, "col":(100,100,100)},
            "goblin":     {"w":30, "h":40, "hp":6,   "spd":2.5, "coin":20, "col":(50,150,50)},
            "skeleton":   {"w":30, "h":45, "hp":12,  "spd":2.0, "coin":30, "col":(220,220,220)},
            "golem":      {"w":50, "h":60, "hp":35,  "spd":1.5, "coin":50, "col":(139,115,85)},
            "wyvern":     {"w":45, "h":35, "hp":15,  "spd":3.8, "coin":60, "col":(50,150,150)}, 
            "gatekeeper": {"w":50, "h":60, "hp":60,  "spd":2.5, "coin":150,"col":(200,100,0)},  
            "elite":      {"w":35, "h":45, "hp":25,  "spd":2.8, "coin":50, "col":(150,50,50)},
            "maou":       {"w":70, "h":80, "hp":150, "spd":3.0, "coin":999,"col":(120,30,120)}  
        }
        st = stats[e_type]
        self.rect = pygame.Rect(x, y, st["w"], st["h"])
        self.hp = st["hp"]
        self.speed = st["spd"]
        self.coin_drop = st["coin"]
        self.color = st["col"]
            
    def update(self, px, py):
        if self.type == "maou":
            self.warp_timer += 1
            if self.warp_timer > 90: 
                for _ in range(10): 
                    nx, ny = random.randint(60, WIDTH-120), random.randint(60, GAME_HEIGHT-250)
                    if math.hypot(nx - px, ny - py) > 150:
                        self.rect.x, self.rect.y = nx, ny; break
                self.warp_timer = 0
        
        dx, dy = px - self.rect.centerx, py - self.rect.centery
        dist = math.hypot(dx, dy)
        if dist > 0:
            self.rect.x += (dx / dist) * self.speed
            self.rect.y += (dy / dist) * self.speed

    def draw(self, surface):
        pygame.draw.ellipse(surface, (0,0,0,100), (self.rect.x, self.rect.bottom-5, self.rect.width, 10)) 
        pygame.draw.rect(surface, self.color, self.rect, border_radius=8)
        
        if self.type == "wolf":
            pygame.draw.polygon(surface, self.color, [(self.rect.left, self.rect.top), (self.rect.left-10, self.rect.top-10), (self.rect.left+10, self.rect.top)]) 
        elif self.type == "goblin":
            pygame.draw.rect(surface, BROWN, (self.rect.left - 5, self.rect.centery - 10, 8, 30)) 
        elif self.type == "wyvern": 
            pygame.draw.polygon(surface, self.color, [(self.rect.left-15, self.rect.top), (self.rect.left, self.rect.centery), (self.rect.left-10, self.rect.bottom)])
            pygame.draw.polygon(surface, self.color, [(self.rect.right+15, self.rect.top), (self.rect.right, self.rect.centery), (self.rect.right+10, self.rect.bottom)])
        elif self.type == "skeleton" or self.type == "elite":
            pygame.draw.rect(surface, SILVER, (self.rect.left - 5, self.rect.centery - 20, 5, 40)) 
        elif self.type == "gatekeeper":
            pygame.draw.rect(surface, (80,80,80), (self.rect.left - 5, self.rect.top - 10, 5, 70)) 
            pygame.draw.polygon(surface, SILVER, [(self.rect.left-5, self.rect.top-10), (self.rect.left-10, self.rect.top-30), (self.rect.left, self.rect.top-30)])
        elif self.type == "maou":
            pygame.draw.polygon(surface, BLACK, [(self.rect.left, self.rect.top), (self.rect.centerx, self.rect.top-30), (self.rect.right, self.rect.top)]) 
            pygame.draw.rect(surface, BROWN, (self.rect.right, self.rect.top, 6, 80)) 
            pygame.draw.circle(surface, RED, (self.rect.right+3, self.rect.top-5), 12)

# --- ストーリーデータ ---
STORY_DATA = [
    {"bg": "village", "texts": ["【第1章：過酷な旅立ち】", "魔物の強さが跳ね上がっている。油断すると即死だ！"], "enemies": [{"type": "slime", "count": 6}]},
    {"bg": "plains", "texts": ["【第2章：牙を剥く平原】", "超高速で迫るオオカミの群れ。足を止めるな！"], "enemies": [{"type": "wolf", "count": 8}]},
    {"bg": "forest", "texts": ["【第3章：狂気の迷い森】", "ゴブリンが大群で押し寄せてきた。囲まれる前に斬れ！"], "enemies": [{"type": "goblin", "count": 8}]},
    {"bg": "forest", "texts": ["【第4章：森の深部】", "ゴブリンとオオカミの挟み撃ちだ！生き残れるか！？"], "enemies": [{"type": "goblin", "count": 5}, {"type": "wolf", "count": 5}]},
    {"bg": "cave", "texts": ["【第5章：死者の廃坑】", "硬い骸骨兵士が暗闇から湧いて出る。武器の強化は必須だ。"], "enemies": [{"type": "skeleton", "count": 8}]},
    {"bg": "lava_cave", "texts": ["【第6章：灼熱の地下】", "灼熱の溶岩地帯。圧倒的な耐久力を持つゴーレムが立ちはだかる！"], "enemies": [{"type": "golem", "count": 6}]},
    {"bg": "snow_mountain", "texts": ["【第7章：吹雪の霊峰】", "空を切り裂くワイバーン！動きが速すぎる、気をつけて！"], "enemies": [{"type": "wyvern", "count": 6}]},
    {"bg": "castle_gate", "texts": ["【第8章：鉄壁の門番】", "魔王城の門。恐ろしい耐久力を持つ門番と骸骨の大軍だ！"], "enemies": [{"type": "gatekeeper", "count": 1}, {"type": "skeleton", "count": 6}]},
    {"bg": "hallway", "texts": ["【第9章：血塗られた回廊】", "城の内部。赤い鎧の精鋭エリート兵たちが本気で殺しにくる！"], "enemies": [{"type": "elite", "count": 8}]},
    {"bg": "throne", "texts": ["【最終章：絶望の玉座】", "魔王「愚かな人間よ。我が絶望の力と、精鋭たちの前に散るが良い！」"], "enemies": [{"type": "maou", "count": 1}, {"type": "elite", "count": 3}]},
    {"bg": "village", "texts": ["【エピローグ】", "信じられない…あの地獄を生き抜いたのか。", "君の圧倒的な強さは、伝説となるだろう！ 〜 HARD CLEAR 〜"], "enemies": []}
]

# --- メインループ関数 (pygbag向けに非同期async化) ---
async def main():
    player = Player(WIDTH//2, (GAME_HEIGHT - 150)//2)
    enemies = []
    
    current_stage = 0
    state = "STORY"
    text_index = 0
    
    upg_costs = [100, 300, 600]
    active_touches = {} # マルチタッチ保持用辞書
    
    running = True
    while running:
        # 1. 入力・イベント処理
        action_trigger = None # iPadタップ等による決定キー(Return/Space)のシミュレート用
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            # 物理キーボード判定
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r: 
                    current_stage, state, text_index = 0, "STORY", 0
                    player = Player(WIDTH//2, (GAME_HEIGHT - 150)//2)
                    enemies = []
                
                if event.key == pygame.K_RETURN or event.key == pygame.K_SPACE:
                    action_trigger = "ENTER"
                elif event.key == pygame.K_1:
                    action_trigger = "SHOP1"
                elif event.key == pygame.K_2:
                    action_trigger = "SHOP2"

            # iPadマルチタッチイベントの取得
            elif event.type == pygame.FINGERDOWN or event.type == pygame.FINGERMOTION:
                # 正しく全体の横幅(WIDTH=800)と縦幅(HEIGHT=760)を掛け合わせる
                fx = int(event.x * WIDTH)
                fy = int(event.y * HEIGHT)
                active_touches[event.finger_id] = (fx, fy)
                
                # タップの瞬間(FINGERDOWN)のみ単発アクションボタンを判定
                if event.type == pygame.FINGERDOWN:
                    if rect_attack.collidepoint(fx, fy):
                        action_trigger = "ENTER"
                    elif rect_shop1.collidepoint(fx, fy) and state == "SHOP":
                        action_trigger = "SHOP1"
                    elif rect_shop2.collidepoint(fx, fy) and state == "SHOP":
                        action_trigger = "SHOP2"
                    elif fy < GAME_HEIGHT and (state == "GAMEOVER" or current_stage == len(STORY_DATA)-1):
                        # ゲームオーバー時やクリア時にゲーム画面を叩くとリスタート
                        current_stage, state, text_index = 0, "STORY", 0
                        player = Player(WIDTH//2, (GAME_HEIGHT - 150)//2)
                        enemies = []

            elif event.type == pygame.FINGERUP:
                if event.finger_id in active_touches:
                    del active_touches[event.finger_id]
            
            # PCマウスでの動作テスト用
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                pos = event.pos
                active_touches["mouse"] = pos # マウスもタッチ扱いとして登録
                if rect_attack.collidepoint(pos): action_trigger = "ENTER"
                elif rect_shop1.collidepoint(pos) and state == "SHOP": action_trigger = "SHOP1"
                elif rect_shop2.collidepoint(pos) and state == "SHOP": action_trigger = "SHOP2"
                elif pos[1] < GAME_HEIGHT and (state == "GAMEOVER" or current_stage == len(STORY_DATA)-1):
                    current_stage, state, text_index = 0, "STORY", 0
                    player = Player(WIDTH//2, (GAME_HEIGHT - 150)//2)
                    enemies = []

            elif event.type == pygame.MOUSEMOTION and event.buttons[0] == 1:
                # マウスドラッグ中も座標を更新
                active_touches["mouse"] = event.pos

            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                if "mouse" in active_touches:
                    del active_touches["mouse"]

        # バーチャルキー入力状態のクリアと割り当て
        vkeys = {"LEFT": False, "RIGHT": False, "UP": False, "DOWN": False, "ATTACK": False}
        
        # 物理キーボードの状態を同期
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:  vkeys["LEFT"] = True
        if keys[pygame.K_RIGHT]: vkeys["RIGHT"] = True
        if keys[pygame.K_UP]:    vkeys["UP"] = True
        if keys[pygame.K_DOWN]:  vkeys["DOWN"] = True
        if keys[pygame.K_SPACE]: vkeys["ATTACK"] = True

        # iPadタッチDパッドの状態を同期 (押しっぱなし対応)
        for pos in active_touches.values():
            if rect_left.collidepoint(pos):  vkeys["LEFT"] = True
            if rect_right.collidepoint(pos): vkeys["RIGHT"] = True
            if rect_up.collidepoint(pos):    vkeys["UP"] = True
            if rect_down.collidepoint(pos):  vkeys["DOWN"] = True
            if rect_attack.collidepoint(pos): vkeys["ATTACK"] = True

        # === シーン毎のロジック振り分け ===
        if action_trigger == "ENTER":
            if state == "STORY":
                text_index += 1
                if text_index >= len(STORY_DATA[current_stage]["texts"]):
                    enemy_data = STORY_DATA[current_stage]["enemies"]
                    if len(enemy_data) > 0:
                        state = "BATTLE" 
                        enemies = []
                        for ed in enemy_data:
                            for _ in range(ed["count"]):
                                while True:
                                    ex, ey = random.randint(60, WIDTH-90), random.randint(60, GAME_HEIGHT-220)
                                    if math.hypot(ex - player.rect.x, ey - player.rect.y) > 250:
                                        enemies.append(Enemy(ex, ey, ed["type"])); break
                    else:
                        text_index -= 1 
            elif state == "SHOP":
                current_stage += 1
                state = "STORY"
                text_index = 0
                player.rect.center = (WIDTH//2, (GAME_HEIGHT - 150)//2)
            elif state == "GAMEOVER":
                current_stage, state, text_index = 0, "STORY", 0
                player = Player(WIDTH//2, (GAME_HEIGHT - 150)//2)
                enemies = []

        elif state == "SHOP":
            current_upg_cost = upg_costs[player.weapon_level - 1] if player.weapon_level < 4 else 0
            if action_trigger == "SHOP1": # 回復
                if player.coins >= 30 and player.hp < player.max_hp:
                    player.coins -= 30
                    player.hp += 1
            elif action_trigger == "SHOP2": # 武器強化
                if player.weapon_level < 4 and player.coins >= current_upg_cost:
                    player.coins -= current_upg_cost
                    player.weapon_level += 1

        if state == "BATTLE":
            player.move_virtual(vkeys)
            
            for enemy in enemies[:]: 
                enemy.update(player.rect.centerx, player.rect.centery)
                
                if player.invincible == 0 and player.rect.colliderect(enemy.rect):
                    player.hp -= 1
                    player.invincible = 45 
                    if player.hp <= 0: state = "GAMEOVER"
                
                if player.attack_timer == 10: 
                    if player.sword_rect and player.sword_rect.colliderect(enemy.rect):
                        enemy.hp -= player.get_damage() 
                        if enemy.hp <= 0:
                            player.coins += enemy.coin_drop 
                            enemies.remove(enemy)
            
            if len(enemies) == 0:
                if current_stage < len(STORY_DATA) - 2:
                    state = "SHOP"
                else:
                    current_stage += 1
                    state = "STORY"
                    text_index = 0

        # === 描画処理 ===
        # 仮想の揺れ用演出をカットして直接画面へ描画（パフォーマンス安定化のため）
        draw_background(screen, STORY_DATA[current_stage]["bg"])

        if state != "GAMEOVER": player.draw(screen)
        for enemy in enemies: enemy.draw(screen)

        # ショップ画面
        if state == "SHOP":
            s_rect = pygame.Rect(100, 80, 600, 280)
            pygame.draw.rect(screen, (30, 10, 10), s_rect, border_radius=10) 
            pygame.draw.rect(screen, GOLD, s_rect, 4, border_radius=10)
            
            screen.blit(large_font.render("=== 武器屋・休憩所 (ぼったくり) ===", True, WHITE), (120, 100))
            screen.blit(font.render(f"所持金: {player.coins} G", True, GOLD), (150, 150))
            screen.blit(small_font.render("下の [回復] ボタンをタップでハート回復 (30 G)", True, WHITE), (150, 190))
            
            current_upg_cost = upg_costs[player.weapon_level - 1] if player.weapon_level < 4 else 0
            upg_text = f"下の [強化] ボタンをタップで武器強化 (費用: {current_upg_cost} G)" if player.weapon_level < 4 else "武器は最大レベルだ！"
            w_names = ["鉄の剣", "鋼の剣", "黄金の剣", "炎の魔剣"]
            screen.blit(small_font.render(f"{upg_text} / 現在: {w_names[player.weapon_level-1]}(Lv{player.weapon_level})", True, WHITE), (150, 230))
            
            if pygame.time.get_ticks() % 1000 < 500:
                screen.blit(small_font.render("▼ [ACTION] ボタンをタップで次ステージへ出発", True, RED), (150, 290))

        # メッセージウィンドウ
        ui_rect = pygame.Rect(0, GAME_HEIGHT - 150, WIDTH, 150)
        pygame.draw.rect(screen, BLACK, ui_rect)
        pygame.draw.rect(screen, RED, ui_rect, 4) 

        if state == "STORY":
            current_text = STORY_DATA[current_stage]["texts"][text_index]
            screen.blit(font.render(current_text, True, WHITE), (30, GAME_HEIGHT - 105))
            if pygame.time.get_ticks() % 1000 < 500:
                screen.blit(small_font.render("▼ [ACTION] ボタンで次へ", True, GOLD), (WIDTH - 240, GAME_HEIGHT - 35))
                
        elif state == "BATTLE":
            screen.blit(small_font.render("【操作】 十字キーで移動 / [ACTION] で剣を振る！", True, WHITE), (30, GAME_HEIGHT - 95))
            status_text = f"魔物の残り: {len(enemies)} 体"
            if current_stage == 7: status_text = f"◆中ボス戦◆ 門番の残りHP: {enemies[0].hp if enemies else 0}"
            elif current_stage == 9: status_text = f"★最終決戦★ 魔王の残りHP: {enemies[0].hp if enemies else 0}"
            screen.blit(font.render(status_text, True, RED), (30, GAME_HEIGHT - 55))
            
        elif state == "GAMEOVER":
            screen.blit(font.render("勇者は無惨にも力尽きてしまった……。", True, RED), (30, GAME_HEIGHT - 105))
            screen.blit(small_font.render("- 画面上部をタップして最初からやり直し -", True, WHITE), (WIDTH - 420, GAME_HEIGHT - 35))

        # 上部ステータスUI
        screen.blit(small_font.render(f"所持金: {player.coins} G", True, GOLD), (WIDTH - 150, 20))
        w_names = ["鉄の剣", "鋼の剣", "黄金の剣", "炎の魔剣"]
        screen.blit(small_font.render(f"武器: {w_names[player.weapon_level-1]}", True, player.get_weapon_color()), (WIDTH - 150, 50))
        
        for i in range(player.max_hp): 
            color = RED if i < player.hp else (40, 40, 40)
            hx, hy = 35 + i * 35, 30
            pygame.draw.circle(screen, color, (hx-6, hy-6), 6); pygame.draw.circle(screen, color, (hx+6, hy-6), 6)
            pygame.draw.polygon(screen, color, [(hx-12, hy-5), (hx+12, hy-5), (hx, hy+12)])

        # --- 4. iPad用オンスクリーンバーチャルパッドの描画 (最下部エリア) ---
        pad_ui_rect = pygame.Rect(0, GAME_HEIGHT, WIDTH, UI_PAD_HEIGHT)
        pygame.draw.rect(screen, PAD_BG_COLOR, pad_ui_rect)
        pygame.draw.line(screen, WHITE, (0, GAME_HEIGHT), (WIDTH, GAME_HEIGHT), 2)

        # 十字キーの描画
        pygame.draw.rect(screen, PAD_BTN_COLOR if not vkeys["UP"] else GOLD, rect_up, border_radius=6)
        pygame.draw.rect(screen, PAD_BTN_COLOR if not vkeys["DOWN"] else GOLD, rect_down, border_radius=6)
        pygame.draw.rect(screen, PAD_BTN_COLOR if not vkeys["LEFT"] else GOLD, rect_left, border_radius=6)
        pygame.draw.rect(screen, PAD_BTN_COLOR if not vkeys["RIGHT"] else GOLD, rect_right, border_radius=6)

        # 十字キーの文字ラベル
        u_s = small_font.render("U", True, WHITE if not vkeys["UP"] else BLACK)
        d_s = small_font.render("D", True, WHITE if not vkeys["DOWN"] else BLACK)
        l_s = small_font.render("L", True, WHITE if not vkeys["LEFT"] else BLACK)
        r_s = small_font.render("R", True, WHITE if not vkeys["RIGHT"] else BLACK)
        screen.blit(u_s, u_s.get_rect(center=rect_up.center))
        screen.blit(d_s, d_s.get_rect(center=rect_down.center))
        screen.blit(l_s, l_s.get_rect(center=rect_left.center))
        screen.blit(r_s, r_s.get_rect(center=rect_right.center))

        # アクション決定・攻撃ボタンの描画
        pygame.draw.rect(screen, RED if not vkeys["ATTACK"] else GOLD, rect_attack, border_radius=12)
        atk_s = font.render("ACTION", True, WHITE if not vkeys["ATTACK"] else BLACK)
        screen.blit(atk_s, atk_s.get_rect(center=rect_attack.center))

        # ショップ用購入ボタン（ショップ状態の時のみ不透明・アクティブ化）
        if state == "SHOP":
            pygame.draw.rect(screen, (0, 150, 255), rect_shop1, border_radius=8)
            pygame.draw.rect(screen, (50, 200, 50), rect_shop2, border_radius=8)
            s1_text = small_font.render("回復 (30G)", True, WHITE)
            s2_text = small_font.render("武器強化", True, WHITE)
        else:
            # 非表示にするか、無効化されたグレーアウト描画にする
            pygame.draw.rect(screen, (60, 60, 60), rect_shop1, border_radius=8)
            pygame.draw.rect(screen, (60, 60, 60), rect_shop2, border_radius=8)
            s1_text = small_font.render("---", True, (200, 200, 200))
            s2_text = small_font.render("---", True, (200, 200, 200))
            
        screen.blit(s1_text, s1_text.get_rect(center=rect_shop1.center))
        screen.blit(s2_text, s2_text.get_rect(center=rect_shop2.center))

        pygame.display.flip()
        await asyncio.sleep(0)  # pygbag環境のフリーズ防止（必須）

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    asyncio.run(main())