import pygame
from pygame.locals import *
import random
import asyncio

# --- 画面サイズ設定 ---
WIDTH, HEIGHT = 1280, 720
FOVS_FACTOR = 400
CAMERA_Y = 150
CAMERA_Z = 200

def project_3d(x, y, z):
    rel_z = z - CAMERA_Z
    if rel_z >= 0: return None
    scale = FOVS_FACTOR / -rel_z
    screen_x = int(WIDTH / 2 + x * scale)
    screen_y = int(HEIGHT / 2 - (y - CAMERA_Y) * scale)
    return (screen_x, screen_y, scale)  # スケール（大きさの倍率）も一緒に返すように変更

def draw_text(surface, text, x, y, size=36, color=(255, 255, 255), center=False):
    font = pygame.font.SysFont("Arial", size, bold=True)
    text_surface = font.render(text, True, color)
    rect = text_surface.get_rect()
    if center: rect.center = (x, y)
    else: rect.topleft = (x, y)
    surface.blit(text_surface, rect)

def draw_grid_3d(surface):
    for i in range(-5, 6):
        x = i * 35
        p_start = project_3d(x, -20, 100)
        p_end = project_3d(x, -20, -1000)
        if p_start and p_end: pygame.draw.line(surface, (0, 100, 200), p_start[:2], p_end[:2], 2)
            
    for j in range(0, 21):
        z = -j * 50
        p_left = project_3d(-175, -20, z)
        p_right = project_3d(175, -20, z)
        if p_left and p_right: pygame.draw.line(surface, (0, 100, 200), p_left[:2], p_right[:2], 1)

def draw_obstacle_3d(surface, obs_x, obs_y, obs_z, obs_type):
    p_data = project_3d(obs_x, obs_y, obs_z)
    if not p_data: return
    px, py, scale = p_data
    size = max(1, int(15 * scale))
    
    if obs_type == "STONE":
        rect = pygame.Rect(px - size, py - size, size * 2, size * 2)
        pygame.draw.rect(surface, (120, 120, 120), rect)
        pygame.draw.rect(surface, (80, 80, 80), rect, 2)
    else:
        pygame.draw.circle(surface, (255, 255, 0), (px, py), size)
        pygame.draw.circle(surface, (200, 200, 0), (px, py), size, 2)

def draw_touch_buttons(surface):
    pygame.draw.rect(surface, (255, 255, 255), (20, 550, 200, 150), 2, border_radius=10)
    draw_text(surface, "LEFT", 120, 625, size=24, center=True)
    pygame.draw.rect(surface, (255, 255, 255), (260, 550, 200, 150), 2, border_radius=10)
    draw_text(surface, "RIGHT", 360, 625, size=24, center=True)
    pygame.draw.rect(surface, (255, 255, 255), (1060, 550, 200, 150), 2, border_radius=10)
    draw_text(surface, "JUMP", 1160, 625, size=24, center=True)

# --- メインループ ---
async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Space Dodge: Image Edition")
    clock = pygame.time.Clock()

    # --- 画像の読み込みと初期設定 ---
    try:
        # player.png を読み込み（アルファチャンネル対応）
        player_img_original = pygame.image.load("player.png").convert_alpha()
    except:
        # 画像がない場合のフォールバック（ダミーのピンクのサーフェス）
        player_img_original = pygame.Surface((64, 64), pygame.SRCALPHA)
        pygame.draw.polygon(player_img_original, (255, 102, 178), [(32, 0), (0, 64), (64, 64)])

    stars = [[random.randint(0, WIDTH), random.randint(0, HEIGHT)] for _ in range(150)]

    running = True
    while running:
        player_x, player_y, player_z = 0.0, 0.0, -100.0
        y_vel = 0.0
        is_jumping = False
        hp = 3
        damage_timer = 0
        state = "PLAYING"
        time_limit = 60.0
        start_ticks = pygame.time.get_ticks()
        obstacles = []
        spawn_timer = 0
        touch_left, touch_right = False, False

        in_game = True
        while in_game:
            current_ticks = pygame.time.get_ticks()
            dt = clock.tick(60)
            
            # 入力処理
            mouse_pos = pygame.mouse.get_pos()
            mouse_pressed = pygame.mouse.get_pressed()
            if mouse_pressed[0]:
                mx, my = mouse_pos
                if state == "PLAYING":
                    touch_left = (20 <= mx <= 220) and (550 <= my <= 700)
                    touch_right = (260 <= mx <= 460) and (550 <= my <= 700)
            else:
                touch_left, touch_right = False, False

            for event in pygame.event.get():
                if event.type == pygame.QUIT: running = False; in_game = False
                if event.type == KEYDOWN:
                    if event.key == K_ESCAPE: running = False; in_game = False
                    if state == "PLAYING" and event.key == K_SPACE and not is_jumping:
                        y_vel = 7.0; is_jumping = True
                    if state != "PLAYING" and event.key == K_r: in_game = False
                if event.type == MOUSEBUTTONDOWN:
                    mx, my = event.pos
                    if state == "PLAYING":
                        if (1060 <= mx <= 1260) and (550 <= my <= 700) and not is_jumping:
                            y_vel = 7.0; is_jumping = True
                    else:
                        in_game = False

            if state == "PLAYING":
                elapsed_time = (current_ticks - start_ticks) / 1000.0
                time_left = max(0, time_limit - elapsed_time)
                if time_left <= 0: state = "CLEAR"

                keys = pygame.key.get_pressed()
                if keys[K_LEFT] or touch_left: player_x -= 4.0
                if keys[K_RIGHT] or touch_right: player_x += 4.0
                player_x = max(min(player_x, 100), -100)

                if is_jumping:
                    player_y += y_vel
                    y_vel -= 0.35
                    if player_y <= 0: player_y = 0; y_vel = 0; is_jumping = False

                spawn_timer += dt
                if spawn_timer > 350:
                    obs_type = random.choice(["STONE", "BALL", "BALL"])
                    obstacles.append([random.uniform(-100, 100), 0, -1000, obs_type])
                    spawn_timer = 0

                if damage_timer > 0: damage_timer -= dt
                    
                new_obstacles = []
                for o in obstacles:
                    o[2] += 12.0
                    if damage_timer <= 0 and abs(o[0] - player_x) < 16 and abs(o[1] - player_y) < 16 and abs(o[2] - player_z) < 15:
                        hp -= 1; damage_timer = 1000
                        if hp <= 0: state = "GAMEOVER"
                    if o[2] < CAMERA_Z: new_obstacles.append(o)
                obstacles = new_obstacles

            # --- 描画処理 ---
            screen.fill((0, 0, 0))
            for s in stars: pygame.draw.circle(screen, (255, 255, 255), s, 1)
            draw_grid_3d(screen)
            for o in obstacles: draw_obstacle_3d(screen, o[0], o[1], o[2], o[3])

            # --- プレイヤー（画像）の描画 ---
            shake_x, shake_y = 0, 0
            if damage_timer > 0:
                shake_x = random.randint(-5, 5)
                shake_y = random.randint(-5, 5)

            p_player = project_3d(player_x, player_y, player_z)
            if p_player:
                px, py, scale = p_player
                px += shake_x
                py += shake_y
                
                # プレイヤーのZ位置に合わせて画像のサイズをスケール調整（今回は固定Zなので約53ピクセル幅になります）
                img_w = max(10, int(40 * scale))
                img_h = max(10, int(40 * scale))
                
                # 高速に画像をリサイズして描画
                scaled_player = pygame.transform.smoothscale(player_img_original, (img_w, img_h))
                img_rect = scaled_player.get_rect()
                img_rect.center = (px, py)
                screen.blit(scaled_player, img_rect)

            if damage_timer > 0 and state == "PLAYING":
                flash_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
                flash_surf.fill((255, 0, 0, 100))
                screen.blit(flash_surf, (0, 0))

            # UI 表示
            if state == "PLAYING":
                draw_text(screen, f"TIME: {time_left:.1f}s", 1050, 30, size=30)
                draw_text(screen, f"HP: {hp}", 50, 30, size=30, color=(255, 50, 50))
                draw_touch_buttons(screen)
            elif state == "GAMEOVER":
                flash_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
                flash_surf.fill((255, 0, 0, 100)); screen.blit(flash_surf, (0, 0))
                draw_text(screen, "GAME OVER", WIDTH // 2, HEIGHT // 2 - 50, size=80, color=(255, 0, 0), center=True)
                draw_text(screen, "Tap Screen or Press 'R' to Restart", WIDTH // 2, HEIGHT // 2 + 50, size=30, center=True)
            elif state == "CLEAR":
                draw_text(screen, "CLEAR!!", WIDTH // 2, HEIGHT // 2 - 50, size=80, color=(255, 215, 0), center=True)
                draw_text(screen, "Tap Screen or Press 'R' to Play Again", WIDTH // 2, HEIGHT // 2 + 50, size=30, center=True)

            pygame.display.flip()
            await asyncio.sleep(0)

    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())