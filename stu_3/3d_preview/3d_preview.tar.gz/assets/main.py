import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
import numpy as np
import asyncio  # 1. asyncioをインポート

# --- load_mtl, load_obj, create_obj_display_list, draw_ground はそのまま ---
def load_mtl(filename):
    materials = {}; current_mtl = None
    try:
        with open(filename, "r") as f:
            for line in f:
                parts = line.split()
                if not parts: continue
                if parts[0] == 'newmtl': current_mtl = parts[1]
                elif parts[0] == 'Kd' and current_mtl: materials[current_mtl] = list(map(float, parts[1:4]))
    except: pass
    return materials

def load_obj(filename, mtl_filename):
    vertices = []; material_faces = {}; current_material = None
    materials = load_mtl(mtl_filename)
    try:
        with open(filename, "r") as f:
            for line in f:
                parts = line.split()
                if not parts: continue
                if parts[0] == 'v': vertices.append(list(map(float, parts[1:4])))
                elif parts[0] == 'usemtl':
                    current_material = parts[1]
                    if current_material not in material_faces: material_faces[current_material] = []
                elif parts[0] == 'f':
                    face = [int(val.split('/')[0]) - 1 for val in parts[1:]]
                    if current_material: material_faces[current_material].append(face)
        v_array = np.array(vertices)
        center = (v_array.min(axis=0) + v_array.max(axis=0)) / 2.0
        vertices = (v_array - center).tolist()
        return vertices, material_faces, materials
    except: return [], {}, {}

def create_obj_display_list(vertices, material_faces, materials):
    list_id = glGenLists(1)
    glNewList(list_id, GL_COMPILE)
    for mtl_name, faces in material_faces.items():
        glColor3fv(materials.get(mtl_name, [0.8, 0.8, 0.8]))
        glBegin(GL_TRIANGLES)
        for face in faces:
            for i in range(1, len(face) - 1):
                glVertex3fv(vertices[face[0]]); glVertex3fv(vertices[face[i]]); glVertex3fv(vertices[face[i+1]])
        glEnd()
    glEndList()
    return list_id

def draw_ground():
    glDisable(GL_LIGHTING)
    glBegin(GL_QUADS)
    glColor3f(0.2, 0.6, 0.2)
    size = 1000.0; height = -50.0 
    glVertex3f(-size, height, -size); glVertex3f(size, height, -size)
    glVertex3f(size, height, size); glVertex3f(-size, height, size)
    glEnd()
    glEnable(GL_LIGHTING)

# 2. main関数を非同期(async)にする
async def main():
    pygame.init()
    display = (1920, 1080)
    pygame.display.set_mode(display, DOUBLEBUF | OPENGL)
    pygame.display.set_caption("3D Jumping & Rotating Character")

    glClearColor(0.5, 0.8, 1.0, 1.0)
    glEnable(GL_DEPTH_TEST)
    glEnable(GL_LIGHTING); glEnable(GL_LIGHT0); glEnable(GL_COLOR_MATERIAL)
    glLightfv(GL_LIGHT0, GL_POSITION, [1, 1, 1, 0])

    gluPerspective(45, (display[0] / display[1]), 1.0, 1000.0)
    glTranslatef(0.0, 0.0, -200.0)

    vertices, m_faces, materials = load_obj('tinker.obj', 'obj.mtl')
    model_list = create_obj_display_list(vertices, m_faces, materials)

    clock = pygame.time.Clock()
    
    angle = 0.0
    y_pos = 0.0       
    y_vel = 0.0       
    gravity = -0.5    
    jump_power = 5.0 
    is_jumping = False

    while True:
        dt = clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); return
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    pygame.quit(); return
                if event.key == K_SPACE and not is_jumping:
                    y_vel = jump_power
                    is_jumping = True

        if is_jumping:
            y_pos += y_vel
            y_vel += gravity
            if y_pos <= 0:
                y_pos = 0
                y_vel = 0
                is_jumping = False

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        draw_ground()

        glPushMatrix()
        glTranslatef(0.0, y_pos, 0.0)
        
        rotate_speed = 0.3 if is_jumping else 0.1
        angle += rotate_speed * dt
        glRotatef(angle, 0, 1, 0)
        
        glRotatef(-90, 1, 0, 0)
        glScalef(0.6, 0.6, 0.6)
        
        glCallList(model_list)
        glPopMatrix()

        pygame.display.flip()
        
        # 3. ループの最後に必ず asyncio.sleep(0) を入れてブラウザに制御を戻す
        await asyncio.sleep(0)

if __name__ == "__main__":
    # 4. 非同期メイン関数を実行
    asyncio.run(main())