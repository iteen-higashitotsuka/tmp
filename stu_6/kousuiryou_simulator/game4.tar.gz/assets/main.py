import pygame
import random
import sys
import asyncio # 追加: pygbagでの非同期処理用

# ==========================================
# 設定変数（ここを自由に変えてください）
# ==========================================
TOTAL_PRECIPITATION = 500.0  # 総降水量 (mm)
TOTAL_HOURS = 1.0            # 期間 (時間)
SIMULATION_SPEED = 500        # シミュレーション速度（1 = リアルタイム, 500 = 超高速）
# ==========================================

# --- 初期設定 ---
pygame.init()
# iPadの画面比率（4:3など）で見やすくなるよう解像度を少し調整
WIDTH, HEIGHT = 1024, 768 
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("降水量シミュレーター")

# --- 日本語フォントの設定 (pygbag・ブラウザ向けに最適化) ---
def get_japanese_font(size):
    # pygbag(WASM環境)のブラウザ側が持つ日本語フォント候補
    font_names = ["notosanscjkjp", "notosansjapanese", "msgothic", "hiraginosansgbw3", "applesgothicneo", "yugothic"]
    available_fonts = pygame.font.get_fonts()
    for f in font_names:
        if f in available_fonts:
            return pygame.font.SysFont(f, size)
    # 見つからない場合は標準フォントを返す（英語表記になりますがクラッシュを防ぎます）
    # ※もし完全に日本語化したい場合は、フォントの「.ttf」ファイルをmain.pyと同じフォルダに置き、
    # pygame.font.Font("フォント名.ttf", size) と記述してください。
    return pygame.font.Font(None, size)

# --- 色と定数 ---
COLOR_BG = pygame.Color(80, 200, 120)       # 背景（エメラルドグリーン）
COLOR_RAIN = pygame.Color(200, 230, 255, 120)
COLOR_WATER = pygame.Color(20, 60, 100, 180)

# 降水強度（mm/h）の計算
rain_intensity = TOTAL_PRECIPITATION / TOTAL_HOURS 
# 1ピクセルを何mmとするか（演出上、100mm = 100px と仮定）
MM_TO_PX = 1.0 

class RainDrop:
    def __init__(self):
        self.reset()
    def reset(self):
        self.x = random.randint(0, WIDTH)
        self.y = random.randint(-HEIGHT, 0)
        self.speed = random.randint(12, 25)
        self.length = random.randint(15, 35)
    def update(self, water_y):
        self.y += self.speed
        if self.y > water_y:
            self.reset()
    def draw(self, surf):
        pygame.draw.line(surf, COLOR_RAIN, (self.x, self.y), (self.x, self.y + self.length), 1)

# --- メイン関数 (pygbag対応のため非同期化) ---
async def main():
    clock = pygame.time.Clock()
    
    font_main = get_japanese_font(36) # 画面サイズに合わせて少し大きく
    font_sub = get_japanese_font(26)

    # 雨粒の準備（強度に合わせて数を調整）
    num_drops = int(min(2000, rain_intensity * 5)) # 強すぎる場合に備えて上限設定
    drops = [RainDrop() for _ in range(num_drops)]

    current_mm = 0.0
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # --- ロジック更新 ---
        # 1フレームあたりの降水量 (mm) = (時間あたりの量 / 3600秒 / FPS) * 倍速
        mm_per_frame = (rain_intensity / 3600 / 60) * SIMULATION_SPEED
        if current_mm < TOTAL_PRECIPITATION:
            current_mm += mm_per_frame

        # 水位の計算（下からせり上がる）
        water_height_px = current_mm * MM_TO_PX
        water_y = HEIGHT - min(HEIGHT, water_height_px)

        for drop in drops:
            drop.update(water_y)

        # --- 描画 ---
        screen.fill(COLOR_BG)

        # 雨粒
        rain_surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        for drop in drops:
            drop.draw(rain_surf)
        screen.blit(rain_surf, (0, 0))

        # 水面
        if water_height_px > 0:
            water_rect = pygame.Rect(0, water_y, WIDTH, HEIGHT - water_y)
            pygame.draw.rect(screen, COLOR_WATER, water_rect)

        # テキスト表示 (英語フォントにフォールバックした場合も考慮して文言を少しシンプルに)
        txt_title = font_main.render(f"Setting: {TOTAL_PRECIPITATION}mm / {TOTAL_HOURS}hour", True, (255, 255, 255))
        txt_now = font_main.render(f"Current: {current_mm:.1f} mm Accumulation", True, (255, 255, 0))
        txt_speed = font_sub.render(f"Intensity: {rain_intensity:.1f} mm/h (Speed: x{SIMULATION_SPEED})", True, (255, 255, 255))
        
        screen.blit(txt_title, (30, 30))
        screen.blit(txt_now, (30, 80))
        screen.blit(txt_speed, (30, 130))

        pygame.display.flip()
        clock.tick(60)
        
        await asyncio.sleep(0) # 追加: pygbagで必須のブラウザフリーズ防止処理

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    asyncio.run(main())