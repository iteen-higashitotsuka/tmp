import pygame
import random
import sys
import math
import asyncio  # 追加: pygbagで動かすための非同期処理モジュール

# 初期設定
pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Galaxy Invader Clone")

# カラー定義
WHITE = (255, 255, 255)
BROWN = (139, 69, 19)
CYAN = (0, 255, 255)
YELLOW_GREEN = (154, 205, 50)
RED = (255, 0, 0)
BLACK = (0, 0, 0)

# --- クラス定義 ---
class Star:
    def __init__(self):
        self.x = random.randint(0, WIDTH)
        self.y = random.randint(0, HEIGHT)
        self.speed = random.uniform(1, 3)
    def update(self):
        self.y += self.speed
        if self.y > HEIGHT:
            self.y = 0
            self.x = random.randint(0, WIDTH)
    def draw(self):
        pygame.draw.circle(screen, WHITE, (int(self.x), int(self.y)), 1)

class Block:
    def __init__(self, x, y, is_white=False):
        self.rect = pygame.Rect(x, y, 60, 30)
        self.color = WHITE if is_white else BROWN
        self.is_white = is_white
        self.alive = True
        self.broken = False
        self.particles = []

    def update(self, speed):
        if not self.broken:
            self.rect.y += speed
        else:
            # 粉々演出
            for p in self.particles:
                p['x'] += p['vx']
                p['y'] += p['vy']
            # プレイヤー付近（y=500）で消滅判定
            if all(p['y'] > 500 for p in self.particles):
                self.alive = False

    def break_block(self):
        self.broken = True
        for _ in range(10):
            self.particles.append({
                'x': self.rect.centerx, 'y': self.rect.centery,
                'vx': random.uniform(-2, 2), 'vy': random.uniform(2, 5)
            })

    def draw(self):
        if not self.broken:
            pygame.draw.rect(screen, self.color, self.rect)
        else:
            for p in self.particles:
                pygame.draw.rect(screen, self.color, (p['x'], p['y'], 4, 4))

def draw_alien(x, y):
    # サングラスをかけたタコ
    pygame.draw.ellipse(screen, (255, 105, 180), (x, y, 60, 50)) # 頭
    for i in range(4): # 足
        pygame.draw.line(screen, (255, 105, 180), (x+10+i*15, y+45), (x+i*20, y+70), 5)
    pygame.draw.rect(screen, BLACK, (x+10, y+15, 40, 10)) # サングラス


# --- メイン関数 (pygbag対応のため非同期化) ---
async def main():
    clock = pygame.time.Clock()
    
    # フォント (pygbagでの文字化け・クラッシュを防ぐためデフォルトフォントに変更)
    font = pygame.font.Font(None, 36)
    large_font = pygame.font.Font(None, 80)

    # ゲーム変数
    player_rect = pygame.Rect(WIDTH//2 - 25, HEIGHT - 60, 50, 40)
    bullets = []
    blocks = []
    stars = [Star() for _ in range(50)]
    score = 0
    start_ticks = pygame.time.get_ticks()
    game_over = False
    game_clear = False
    explosion_timer = 0

    # ブロック生成 (5行10列)
    white_indices = random.sample(range(50), 2)
    for i in range(50):
        row = i // 10
        col = i % 10
        is_white = i in white_indices
        blocks.append(Block(col * 75 + 30, row * 40 + 50, is_white))

    alien_x = -100
    alien_y = 200

    # --- iPad/スマホ用 タッチボタン設定 ---
    btn_left = pygame.Rect(20, HEIGHT - 120, 90, 90)
    btn_right = pygame.Rect(130, HEIGHT - 120, 90, 90)
    btn_fire = pygame.Rect(WIDTH - 130, HEIGHT - 120, 110, 90)
    active_touches = {} # 複数の指を追跡するための辞書

    running = True
    while running:
        screen.fill(BLACK)
        
        # イベント処理
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            # [キーボード] ビーム発射
            if event.type == pygame.KEYDOWN and not game_over and not game_clear:
                if event.key == pygame.K_SPACE:
                    bullets.append(pygame.Rect(player_rect.centerx - 2, player_rect.top, 5, 15))

            # [タッチパネル] 画面に指が触れたとき
            if event.type == pygame.FINGERDOWN:
                active_touches[event.finger_id] = (event.x * WIDTH, event.y * HEIGHT)
                # FIREボタンをタップしたらビーム発射
                if btn_fire.collidepoint(event.x * WIDTH, event.y * HEIGHT) and not game_over and not game_clear:
                    bullets.append(pygame.Rect(player_rect.centerx - 2, player_rect.top, 5, 15))

            # [タッチパネル] 指が動いたとき
            if event.type == pygame.FINGERMOTION:
                active_touches[event.finger_id] = (event.x * WIDTH, event.y * HEIGHT)

            # [タッチパネル] 指が離れたとき
            if event.type == pygame.FINGERUP:
                if event.finger_id in active_touches:
                    del active_touches[event.finger_id]

            # [マウス] (PCでのテスト用)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if btn_fire.collidepoint(event.pos) and not game_over and not game_clear:
                    bullets.append(pygame.Rect(player_rect.centerx - 2, player_rect.top, 5, 15))

        if not game_over and not game_clear:
            # 時間計算
            seconds = (pygame.time.get_ticks() - start_ticks) // 1000
            timer = max(0, 180 - seconds)
            if timer <= 0: game_over = True

            # --- 移動処理の統合 (キーボード + タッチ + マウス) ---
            keys = pygame.key.get_pressed()
            move_left = keys[pygame.K_LEFT]
            move_right = keys[pygame.K_RIGHT]

            # タッチの判定
            for pos in active_touches.values():
                if btn_left.collidepoint(pos): move_left = True
                if btn_right.collidepoint(pos): move_right = True
            
            # マウスクリック&ドラッグの判定
            if pygame.mouse.get_pressed()[0]:
                pos = pygame.mouse.get_pos()
                if btn_left.collidepoint(pos): move_left = True
                if btn_right.collidepoint(pos): move_right = True

            # 実際の座標移動
            if move_left and player_rect.left > 0: player_rect.x -= 5
            if move_right and player_rect.right < WIDTH: player_rect.x += 5

            # 背景更新
            for star in stars: star.update()

            # ビーム更新
            for b in bullets[:]:
                b.y -= 7
                if b.bottom < 0: bullets.remove(b)

            # ブロック更新
            all_destroyed = True
            for b in blocks:
                if b.alive:
                    b.update(0.3) # ゆっくり降下
                    if not b.broken:
                        all_destroyed = False
                        # 衝突判定 (ビーム vs ブロック)
                        for bullet in bullets[:]:
                            if b.rect.colliderect(bullet):
                                b.break_block()
                                bullets.remove(bullet)
                                score += 1000 if b.is_white else 50
                        # 衝突判定 (プレイヤー vs ブロック)
                        if b.rect.colliderect(player_rect):
                            game_over = True
                            explosion_timer = 30
            
            if all_destroyed: game_clear = True

        # --- 描画処理 ---
        for star in stars: star.draw()
        
        # プレイヤー描画
        pygame.draw.polygon(screen, (200, 200, 200), [
            (player_rect.centerx, player_rect.top),
            (player_rect.left, player_rect.bottom),
            (player_rect.right, player_rect.bottom)
        ])
        
        for b in bullets: pygame.draw.rect(screen, CYAN, b)
        for b in blocks: 
            if b.alive: b.draw()

        # 宇宙人演出 (10秒後)
        if not game_over and not game_clear:
            if seconds >= 10:
                alien_x += 4
                alien_y += math.sin(alien_x * 0.05) * 5
                draw_alien(alien_x, alien_y)

        # UI表示
        screen.blit(font.render(f"TIME: {timer}", True, WHITE), (10, 10))
        screen.blit(font.render(f"SCORE: {score}", True, WHITE), (10, 50))

        if game_clear:
            msg = large_font.render("GAME CLEAR", True, YELLOW_GREEN)
            screen.blit(msg, (WIDTH//2 - 200, HEIGHT//2 - 40))
        
        if game_over:
            # 爆発演出
            if explosion_timer > 0:
                for i in range(10):
                    pygame.draw.circle(screen, RED, (player_rect.centerx + random.randint(-50,50), player_rect.centery + random.randint(-50,50)), random.randint(20, 60))
                explosion_timer -= 1
            msg = large_font.render("GAME OVER", True, RED)
            screen.blit(msg, (WIDTH//2 - 180, HEIGHT//2 - 40))

        # --- タッチ用ボタンの描画 (半透明) ---
        btn_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        # ボタンの背景
        pygame.draw.rect(btn_surface, (100, 100, 100, 120), btn_left, border_radius=15)
        pygame.draw.rect(btn_surface, (100, 100, 100, 120), btn_right, border_radius=15)
        pygame.draw.rect(btn_surface, (255, 50, 50, 120), btn_fire, border_radius=15)
        
        # ボタンの文字
        btn_surface.blit(font.render("<", True, WHITE), (btn_left.centerx - 10, btn_left.centery - 10))
        btn_surface.blit(font.render(">", True, WHITE), (btn_right.centerx - 10, btn_right.centery - 10))
        btn_surface.blit(font.render("FIRE", True, WHITE), (btn_fire.centerx - 30, btn_fire.centery - 10))
        
        screen.blit(btn_surface, (0, 0))

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)  # pygbagでブラウザをフリーズさせないための必須処理

# スクリプト実行
if __name__ == "__main__":
    asyncio.run(main())