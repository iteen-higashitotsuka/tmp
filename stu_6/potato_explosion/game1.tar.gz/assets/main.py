import pygame
import random
import sys
import time
import asyncio  # 追加: pygbagで非同期処理を行うためのモジュール

# --- 設定 ---
WIDTH, HEIGHT = 800, 700
GRID_SIZE = 3
CELL_SIZE = 80
# 陣地設定
P2_AREA_Y = 100  # 相手（上側）
P1_AREA_Y = 400  # 自分（下側）
BOARD_X = (WIDTH - (CELL_SIZE * 3)) // 2

# カラー
WHITE = (255, 255, 255)
BLACK = (20, 20, 20)
POTATO_COLOR = (240, 210, 120)
P1_COLOR = (50, 150, 255)
P2_COLOR = (255, 80, 80)
BOMB_COLOR = (50, 50, 50)
TIMER_COLOR = (255, 255, 0)

class Chip:
    def __init__(self, x, y, owner_side):
        self.rect = pygame.Rect(x, y, 70, 60)
        self.owner_side = owner_side  # どの陣地にあるか (1:自分側, 2:相手側)
        self.has_bomb = False
        self.is_flipped = False

    def draw(self, screen, font, phase, show_bombs_of_owner=None):
        if not self.is_flipped:
            pygame.draw.ellipse(screen, POTATO_COLOR, self.rect)
            # 配置中、自分が仕掛けた爆弾だけ表示
            if phase == "SETTING" and self.has_bomb and self.owner_side != show_bombs_of_owner:
                pygame.draw.circle(screen, BOMB_COLOR, self.rect.center, 8)
        else:
            color = BOMB_COLOR if self.has_bomb else (200, 200, 200)
            pygame.draw.ellipse(screen, color, self.rect)
            msg = "BOMB!" if self.has_bomb else "SAFE"
            text = font.render(msg, True, WHITE if self.has_bomb else BLACK)
            screen.blit(text, text.get_rect(center=self.rect.center))

# 変更: メイン関数を非同期関数（async def）にする
async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("爆発ポテチ：30秒設置バトル")
    clock = pygame.time.Clock()
    
    # 変更: pygbagではシステムフォント(SysFont)がクラッシュする原因になるため、デフォルトフォントを指定
    # ※注意: デフォルトフォントは日本語に対応していないため、文字化け（□）する可能性があります。
    # 綺麗に表示したい場合は、日本語対応の「.ttf」ファイルを同じフォルダに入れ、
    # font = pygame.font.Font("your_font.ttf", 20) のように書き換えてください。
    font = pygame.font.Font("NotoSansJP-VariableFont_wght.ttf", 24)
    large_font = pygame.font.Font("NotoSansJP-VariableFont_wght.ttf", 36)

    # チップ作成 (P1側とP2側)
    p1_chips = [Chip(BOARD_X + (i%3)*CELL_SIZE, P1_AREA_Y + (i//3)*CELL_SIZE, 1) for i in range(9)]
    p2_chips = [Chip(BOARD_X + (i%3)*CELL_SIZE, P2_AREA_Y + (i//3)*CELL_SIZE, 2) for i in range(9)]
    all_chips = p1_chips + p2_chips

    phase = "SETTING"
    current_setter = 1
    p1_bombs_left = 3
    p2_bombs_left = 3
    start_time = time.time()
    
    current_player = 1
    p1_hits = 0
    p2_hits = 0
    winner = None

    while True:
        screen.fill(BLACK)
        elapsed = time.time() - start_time
        remaining = max(0, 30 - int(elapsed))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if phase == "SETTING":
                    # P1はP2のチップに、P2はP1のチップに仕掛ける
                    target_list = p2_chips if current_setter == 1 else p1_chips
                    bom_left = p1_bombs_left if current_setter == 1 else p2_bombs_left
                    
                    for c in target_list:
                        if c.rect.collidepoint(event.pos) and not c.has_bomb and bom_left > 0:
                            c.has_bomb = True
                            if current_setter == 1: p1_bombs_left -= 1
                            else: p2_bombs_left -= 1
                
                elif phase == "PLAY" and not winner:
                    for c in all_chips:
                        if c.rect.collidepoint(event.pos) and not c.is_flipped:
                            c.is_flipped = True
                            if c.has_bomb:
                                if current_player == 1: p1_hits += 1
                                else: p2_hits += 1
                                if p1_hits >= 3: winner = 2
                                if p2_hits >= 3: winner = 1
                            current_player = 1 if current_player == 2 else 2

            if event.type == pygame.KEYDOWN:
                if phase == "SETTING":
                    if event.key == pygame.K_RETURN:
                        if current_setter == 1:
                            current_setter = 2
                            start_time = time.time() # タイマーリセット
                        else:
                            phase = "PLAY"

        # --- 自動ランダム配置 (時間切れ) ---
        if phase == "SETTING" and remaining <= 0:
            target_list = p2_chips if current_setter == 1 else p1_chips
            while (p1_bombs_left > 0 if current_setter == 1 else p2_bombs_left > 0):
                c = random.choice(target_list)
                if not c.has_bomb:
                    c.has_bomb = True
                    if current_setter == 1: p1_bombs_left -= 1
                    else: p2_bombs_left -= 1
            # 自動で次へ
            if current_setter == 1:
                current_setter = 2
                start_time = time.time()
            else:
                phase = "PLAY"

        # --- 描画 ---
        # 境界線
        pygame.draw.line(screen, WHITE, (0, HEIGHT//2), (WIDTH, HEIGHT//2), 2)

        if phase == "SETTING":
            # 案内テキスト
            color = P1_COLOR if current_setter == 1 else P2_COLOR
            side_name = "相手(上)" if current_setter == 1 else "自分(下)"
            msg = f"P{current_setter}: {side_name}のチップに3つ爆弾を隠せ！"
            timer_txt = large_font.render(f"残り時間: {remaining}s", True, TIMER_COLOR)
            instr = font.render(msg, True, color)
            enter_txt = font.render("完了したらENTER", True, WHITE)
            screen.blit(instr, (WIDTH//2 - instr.get_width()//2, 20))
            screen.blit(timer_txt, (WIDTH//2 - timer_txt.get_width()//2, HEIGHT//2 - 25))
            screen.blit(enter_txt, (WIDTH//2 - enter_txt.get_width()//2, HEIGHT - 40))
            
            # チップ描画（現在操作している人が仕掛けたものだけ表示）
            for c in all_chips:
                c.draw(screen, font, phase, show_bombs_of_owner=current_setter)

        else: # PLAY / RESULT
            for c in all_chips:
                c.draw(screen, font, phase)
            
            # スコア表示
            p1_ui = font.render(f"P1爆弾回避: {3-p1_hits}/3", True, P1_COLOR)
            p2_ui = font.render(f"P2爆弾回避: {3-p2_hits}/3", True, P2_COLOR)
            screen.blit(p1_ui, (20, HEIGHT - 40))
            screen.blit(p2_ui, (20, 20))

            if winner:
                res = large_font.render(f"プレイヤー {winner} の勝利！", True, TIMER_COLOR)
                screen.blit(res, (WIDTH//2 - res.get_width()//2, HEIGHT//2 - 20))
            else:
                turn = font.render(f"P{current_player} のターン", True, WHITE)
                screen.blit(turn, (WIDTH - 150, HEIGHT//2 - 10))

        pygame.display.flip()
        clock.tick(60)
        
        # 追加: pygbagでブラウザをフリーズさせないために毎フレーム処理を譲る
        await asyncio.sleep(0)

# 変更: スクリプト実行時に非同期関数を実行するように変更
if __name__ == "__main__":
    asyncio.run(main())