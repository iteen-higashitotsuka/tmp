import pygame
import sys
import random
import asyncio
from collections import defaultdict

# --- 定数設定 ---
WIDTH, HEIGHT = 800, 450
FPS = 60
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
GRAY = (180, 180, 180)
ORANGE = (255, 165, 0)
GRAVITY = 0.8
WALK_SPEED = 5
JUMP_POWER = -15
MAX_ULT = 10

# 天井（安全地帯）の設定
CEILINGS = [pygame.Rect(150, 150, 120, 20), pygame.Rect(530, 150, 120, 20)]

class Projectile:
    """レーザーやフライパン用のクラス"""
    def __init__(self, x, y, type, direction, owner):
        self.type = type
        self.owner = owner # 投げたプレイヤー
        self.rect = pygame.Rect(x, y, 30, 10 if type == 'laser' else 25)
        self.speed = 15 * direction
        self.vel_y = -8 if type == 'pan' else 0
        self.active = True

    def update(self):
        self.rect.x += self.speed
        if self.type == 'pan':
            self.vel_y += 0.5
            self.rect.y += self.vel_y
        if self.rect.x < -50 or self.rect.x > WIDTH + 50 or self.rect.y > HEIGHT:
            self.active = False

class Meteor:
    def __init__(self):
        # 隕石の初期位置をランダムに設定
        self.rect = pygame.Rect(random.randint(0, WIDTH-20), random.randint(-600, -50), 15, 15)
        self.speed = random.randint(5, 9)

    def fall(self):
        # 下に落とす
        self.rect.y += self.speed

    def draw(self, surface):
        # 隕石を画面に描画する
        pygame.draw.circle(surface, ORANGE, self.rect.center, 10)

class SpecialEffect:
    def __init__(self, type):
        self.type = type
        self.timer = 50
        self.stars = [[random.randint(0, WIDTH), random.randint(-200, 0), 
                       (random.randint(0,255), random.randint(0,255), random.randint(0,255))] for _ in range(50)]

    def update(self, surface):
        if self.type == 'explosion':
            overlay = pygame.Surface((WIDTH, HEIGHT))
            overlay.set_alpha(self.timer * 5)
            overlay.fill(RED)
            surface.blit(overlay, (0,0))
        else:
            for s in self.stars:
                s[1] += 15
                pygame.draw.circle(surface, s[2], (s[0], s[1]), 8)
        self.timer -= 1

class Player:
    def __init__(self, x, y, color, controls):
        self.rect = pygame.Rect(x, y, 40, 60)
        self.color = color
        self.controls = controls
        self.hp, self.ult_charge, self.meteor_hits = 200, 0, 0
        self.vel_y, self.is_jumping = 0, False
        self.is_attacking = False
        self.cooldown = 0
        self.invincible = 0
        self.dir = 1 if x < WIDTH/2 else -1

    def move(self, keys):
        if keys[self.controls['left']]: 
            self.rect.x -= WALK_SPEED
            self.dir = -1
        if keys[self.controls['right']]: 
            self.rect.x += WALK_SPEED
            self.dir = 1
        if keys[self.controls['up']] and not self.is_jumping:
            self.vel_y = JUMP_POWER
            self.is_jumping = True

        self.vel_y += GRAVITY
        self.rect.y += self.vel_y
        if self.rect.bottom >= HEIGHT - 20:
            self.rect.bottom, self.vel_y, self.is_jumping = HEIGHT - 20, 0, False
        self.rect.clamp_ip(pygame.Rect(0, 0, WIDTH, HEIGHT))
        if self.invincible > 0: self.invincible -= 1
        if self.cooldown > 0: self.cooldown -= 1

    def draw(self, surface):
        x, y = self.rect.centerx, self.rect.y
        # 棒人間の描画
        pygame.draw.circle(surface, self.color, (x, y + 10), 10, 2)
        pygame.draw.line(surface, self.color, (x, y + 20), (x, y + 45), 2)
        pygame.draw.line(surface, self.color, (x, y + 45), (x - 10, y + 60), 2)
        pygame.draw.line(surface, self.color, (x, y + 45), (x + 10, y + 60), 2)
        if self.is_attacking:
            pygame.draw.line(surface, self.color, (x, y + 30), (x + 40*self.dir, y + 30), 4)

async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Stickman Battle: Meteor & Skills")
    clock = pygame.time.Clock()
    
    # 日本語フォント非対応環境（ブラウザ等）でも動くようにデフォルトの英数フォントを利用
    font = pygame.font.Font(None, 24)
    large_font = pygame.font.Font(None, 80)
    
    p1 = Player(100, 300, RED, {'up':pygame.K_w, 'left':pygame.K_a, 'right':pygame.K_d, 'attack':pygame.K_s, 'ult':pygame.K_9, 'pan':pygame.K_2})
    p2 = Player(660, 300, BLACK, {'up':pygame.K_UP, 'left':pygame.K_LEFT, 'right':pygame.K_RIGHT, 'attack':pygame.K_DOWN, 'ult':pygame.K_0, 'laser':pygame.K_1})
    
    meteors, effects, projectiles = [], [], []
    start_ticks = pygame.time.get_ticks()
    game_over = False
    winner = ""

    # タッチ入力用のオンスクリーンボタン設定
    buttons = [
        # P1 (左側)
        {"rect": pygame.Rect(10, 380, 50, 50), "key": pygame.K_a, "label": "<"},
        {"rect": pygame.Rect(130, 380, 50, 50), "key": pygame.K_d, "label": ">"},
        {"rect": pygame.Rect(70, 320, 50, 50), "key": pygame.K_w, "label": "JMP"},
        {"rect": pygame.Rect(70, 380, 50, 50), "key": pygame.K_s, "label": "ATK"},
        {"rect": pygame.Rect(200, 380, 50, 50), "key": pygame.K_2, "label": "PAN"},
        {"rect": pygame.Rect(260, 380, 50, 50), "key": pygame.K_9, "label": "ULT"},

        # P2 (右側)
        {"rect": pygame.Rect(620, 380, 50, 50), "key": pygame.K_LEFT, "label": "<"},
        {"rect": pygame.Rect(740, 380, 50, 50), "key": pygame.K_RIGHT, "label": ">"},
        {"rect": pygame.Rect(680, 320, 50, 50), "key": pygame.K_UP, "label": "JMP"},
        {"rect": pygame.Rect(680, 380, 50, 50), "key": pygame.K_DOWN, "label": "ATK"},
        {"rect": pygame.Rect(550, 380, 50, 50), "key": pygame.K_1, "label": "LSR"},
        {"rect": pygame.Rect(490, 380, 50, 50), "key": pygame.K_0, "label": "ULT"},
    ]
    active_fingers = {}

    while True:
        screen.fill(WHITE)
        elapsed = (pygame.time.get_ticks() - start_ticks) / 1000

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            
            # マルチタッチ操作の処理
            elif event.type == pygame.FINGERDOWN or event.type == pygame.FINGERMOTION:
                active_fingers[event.finger_id] = (event.x * WIDTH, event.y * HEIGHT)
            elif event.type == pygame.FINGERUP:
                if event.finger_id in active_fingers:
                    del active_fingers[event.finger_id]
            
            # PCデバッグ用のマウス操作（クリックとドラッグ）
            elif event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.MOUSEMOTION:
                if pygame.mouse.get_pressed()[0]:
                    active_fingers['mouse'] = event.pos
                else:
                    if 'mouse' in active_fingers: del active_fingers['mouse']
            elif event.type == pygame.MOUSEBUTTONUP:
                if 'mouse' in active_fingers: del active_fingers['mouse']

        # キーボードとタッチ入力の統合
        keys = pygame.key.get_pressed()
        vkeys = defaultdict(bool)
        for k in range(len(keys)):
            vkeys[k] = keys[k]
        
        for pos in active_fingers.values():
            for btn in buttons:
                if btn["rect"].collidepoint(pos):
                    vkeys[btn["key"]] = True

        if not game_over:
            p1.move(vkeys)
            p2.move(vkeys)

            # 剣攻撃判定
            for p, opp in [(p1, p2), (p2, p1)]:
                if vkeys[p.controls['attack']] and p.cooldown == 0:
                    p.is_attacking, p.cooldown = True, 25
                    if p.rect.inflate(40, 0).colliderect(opp.rect):
                        opp.hp -= random.randint(2, 5)
                        p.ult_charge = min(MAX_ULT, p.ult_charge + 1)
                if p.cooldown < 15: p.is_attacking = False

            # 特殊武器発動
            if vkeys[p1.controls['pan']] and p1.cooldown == 0:
                projectiles.append(Projectile(p1.rect.centerx, p1.rect.centery, 'pan', p1.dir, p1))
                p1.cooldown = 45
       
            if vkeys[p2.controls['laser']] and p2.cooldown == 0:
                projectiles.append(Projectile(p2.rect.centerx, p2.rect.centery, 'laser', p2.dir, p2))
                p2.cooldown = 40

            # 必殺技
            if vkeys[p1.controls['ult']] and p1.ult_charge >= MAX_ULT:
                p1.ult_charge, p2.hp = 0, p2.hp - 50
                effects.append(SpecialEffect('stars'))
            if vkeys[p2.controls['ult']] and p2.ult_charge >= MAX_ULT:
                p2.ult_charge, p1.hp = 0, p1.hp - 50
                effects.append(SpecialEffect('explosion'))

            # 飛び道具更新・衝突
            for pr in projectiles[:]:
                pr.update()
                target = p2 if pr.owner == p1 else p1
                if pr.rect.colliderect(target.rect):
                    target.hp -= 30 if pr.type == 'pan' else 15
                    pr.active = False
                if not pr.active:
                    projectiles.remove(pr)

            # 隕石更新 (6-16秒)
            if 6 <= elapsed <= 16:
                if len(meteors) < 25: meteors.append(Meteor())
            for m in meteors[:]:
                m.fall()
                for p in [p1, p2]:
                    # 安全地帯チェック: プレイヤーの上に天井があるか
                    safe = any(c.left < p.rect.centerx < c.right and c.top > m.rect.y for c in CEILINGS)
                    # かつプレイヤー自身が天井より下にいる
                    in_shelter = any(c.left < p.rect.centerx < c.right and p.rect.top > c.bottom for c in CEILINGS)
                    
                    if p.rect.colliderect(m.rect) and p.invincible == 0:
                        if not in_shelter:
                            p.hp -= 10
                            p.meteor_hits += 1
                            p.invincible = 30
                        m.rect.y = HEIGHT + 100
                if m.rect.y > HEIGHT:
                    meteors.remove(m)

            if p1.hp <= 0 or p1.meteor_hits >= 3: winner, game_over = "PLAYER 2 WIN!", True
            if p2.hp <= 0 or p2.meteor_hits >= 3: winner, game_over = "PLAYER 1 WIN!", True

        # 描画
        for c in CEILINGS: pygame.draw.rect(screen, GRAY, c)
        pygame.draw.line(screen, GRAY, (0, HEIGHT-20), (WIDTH, HEIGHT-20), 4)
        p1.draw(screen)
        p2.draw(screen)
        for m in meteors: m.draw(screen)
        for e in effects[:]:
            e.update(screen)
            if e.timer <= 0: effects.remove(e)
        for pr in projectiles:
            color = GREEN if pr.type == 'laser' else (100, 100, 100)
            pygame.draw.ellipse(screen, color, pr.rect)

        # UI表示
        p1_info = font.render(f"P1 HP:{max(0,p1.hp)} Gauge:{p1.ult_charge}/10 Hits:{p1.meteor_hits}/3", True, RED)
        p2_info = font.render(f"P2 HP:{max(0,p2.hp)} Gauge:{p2.ult_charge}/10 Hits:{p2.meteor_hits}/3", True, BLACK)
        screen.blit(p1_info, (10, 10))
        screen.blit(p2_info, (WIDTH - 360, 10))
        
        if 0 < 6 - elapsed < 6:
            msg = font.render(f"METEOR ALERT: {int(6-elapsed)+1}", True, ORANGE)
            screen.blit(msg, (WIDTH//2 - 80, 20))

        if game_over:
            res = large_font.render(winner, True, (0, 150, 0))
            screen.blit(res, (WIDTH//2 - res.get_width()//2, HEIGHT//2 - 40))

        # オンスクリーンボタンの描画 (半透明)
        btn_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        for btn in buttons:
            color = (150, 150, 150, 200) if vkeys[btn["key"]] else (200, 200, 200, 100)
            pygame.draw.rect(btn_surface, color, btn["rect"], border_radius=8)
            pygame.draw.rect(btn_surface, (50, 50, 50, 200), btn["rect"], 2, border_radius=8)
            label = font.render(btn["label"], True, BLACK)
            btn_surface.blit(label, label.get_rect(center=btn["rect"].center))
        screen.blit(btn_surface, (0, 0))

        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0) # ブラウザのフリーズ防止

if __name__ == "__main__":
    asyncio.run(main())