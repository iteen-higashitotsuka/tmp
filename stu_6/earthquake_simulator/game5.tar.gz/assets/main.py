import pygame
import random
import sys
import math
import asyncio # 追加: pygbagでの非同期処理用

# ==========================================
# 設定変数（ここを自由に変えてください）
# ==========================================
# 揺れの強さ (0 = なし, 1 = 弱, 5 = 強, 10 = 壊滅的)
SEISMIC_INTENSITY = 6.0 

# 建物の数
NUM_BUILDINGS = 10 # 画面幅を広げたので少し増やしました
# ==========================================

# --- 初期設定 ---
pygame.init()
# iPadの画面比率（4:3など）で見やすくなるよう解像度を調整
WIDTH, HEIGHT = 1024, 768 

# 視点の揺れを表現するため、少し大きめのSurfaceに描画してから画面にBlitする
display_surface = pygame.Surface((WIDTH, HEIGHT))
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("地震シミュレーター")

# --- 日本語フォントの設定 (pygbag・ブラウザ向けに最適化) ---
def get_japanese_font(size):
    font_names = ["notosanscjkjp", "notosansjapanese", "msgothic", "hiraginosansgbw3", "applesgothicneo", "yugothic"]
    available_fonts = pygame.font.get_fonts()
    for f in font_names:
        if f in available_fonts:
            return pygame.font.SysFont(f, size)
    # フォントが見つからない場合は標準フォントを返す（英語表記になりますがクラッシュを防ぎます）
    return pygame.font.Font(None, size)

# --- 色の定義 ---
COLOR_BG = pygame.Color(30, 30, 35)      # 夜空のような暗い背景
COLOR_GROUND = pygame.Color(60, 40, 30)  # 地面
COLOR_BUILDING = pygame.Color(100, 100, 110) # 建物
COLOR_WINDOW = pygame.Color(255, 255, 150, 150) # 窓の明かり

# --- クラス定義 ---
class Building:
    """揺れる建物"""
    def __init__(self, x, w, h):
        self.original_x = x
        self.x = x
        self.y = HEIGHT - h - 80 # 地面（高さ80）より少し上に配置
        self.width = w
        self.height = h
        
        # 建物ごとの固有振動（揺れやすさ）をランダムに設定
        self.vibration_factor = random.uniform(0.8, 1.3)
        # 窓の配置をランダムに生成
        self.windows = []
        for _ in range(int(h / 35)):
            for _ in range(int(w / 25)):
                 if random.random() > 0.3: # 70%の確率で窓を配置
                     self.windows.append((random.randint(5, w-15), random.randint(5, h-25)))

    def update(self, time, intensity):
        """地震の波と固有振動に基づいて位置を計算"""
        shake_x = math.sin(time * 0.01 * self.vibration_factor * (intensity + 1)) * intensity * 5
        self.x = self.original_x + shake_x

    def draw(self, surf):
        # 建物本体
        rect = pygame.Rect(self.x, self.y, self.width, self.height)
        pygame.draw.rect(surf, COLOR_BUILDING, rect)
        
        # 窓
        for wx, wy in self.windows:
            window_rect = pygame.Rect(self.x + wx, self.y + wy, 10, 15)
            # 震度が大きいと、窓の明かりがチカチカする演出（グローバル変数を参照する形に修正）
            alpha = random.randint(100, 255) if SEISMIC_INTENSITY > 4 else 200
            pygame.draw.rect(surf, (255, 255, 150, alpha), window_rect)


# --- メイン関数 (pygbag対応のため非同期化) ---
async def main():
    global SEISMIC_INTENSITY # 震度の変更を関数内で行うためglobal宣言
    clock = pygame.time.Clock()
    
    font_main = get_japanese_font(42) # 画面に合わせてサイズを大きく
    font_sub = get_japanese_font(26)

    # --- オブジェクトの生成 ---
    buildings = []
    gap = WIDTH / NUM_BUILDINGS
    for i in range(NUM_BUILDINGS):
        w = random.randint(50, 90)
        h = random.randint(200, 550)
        x = i * gap + (gap - w) / 2
        buildings.append(Building(x, w, h))

    # --- iPad用 タッチボタンの設定 ---
    btn_minus = pygame.Rect(50, HEIGHT - 180, 100, 80)
    btn_plus = pygame.Rect(180, HEIGHT - 180, 100, 80)

    time_counter = 0
    running = True

    while running:
        dt = clock.tick(60)
        
        # 1. イベント処理
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            # [キーボード入力] 震度を変更
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP: SEISMIC_INTENSITY = min(10.0, SEISMIC_INTENSITY + 0.5)
                if event.key == pygame.K_DOWN: SEISMIC_INTENSITY = max(0.0, SEISMIC_INTENSITY - 0.5)
            
            # [タッチパネル入力 (iPad用)]
            if event.type == pygame.FINGERDOWN:
                fx, fy = event.x * WIDTH, event.y * HEIGHT
                if btn_plus.collidepoint(fx, fy):
                    SEISMIC_INTENSITY = min(10.0, SEISMIC_INTENSITY + 0.5)
                if btn_minus.collidepoint(fx, fy):
                    SEISMIC_INTENSITY = max(0.0, SEISMIC_INTENSITY - 0.5)

            # [マウスクリック入力 (PCデバッグ用)]
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if btn_plus.collidepoint(event.pos):
                        SEISMIC_INTENSITY = min(10.0, SEISMIC_INTENSITY + 0.5)
                    if btn_minus.collidepoint(event.pos):
                        SEISMIC_INTENSITY = max(0.0, SEISMIC_INTENSITY - 0.5)

        # 2. 状態更新
        time_counter += dt # 経過時間をミリ秒で加算
        
        # 建物それぞれの揺れを更新
        for b in buildings:
            b.update(time_counter, SEISMIC_INTENSITY)

        # 視点（カメラ）の揺れ（スクリーンシェイク）の計算
        camera_shake_x = 0
        camera_shake_y = 0
        if SEISMIC_INTENSITY > 2.0:
            # 震度に応じて、ランダムに画面をずらす
            shake_range = int(SEISMIC_INTENSITY * 2.5)
            camera_shake_x = random.randint(-shake_range, shake_range)
            camera_shake_y = random.randint(-shake_range, shake_range)

        # 3. 描画処理
        # display_surface（仮想画面）に描画
        display_surface.fill(COLOR_BG)
        
        # 地面
        pygame.draw.rect(display_surface, COLOR_GROUND, (0, HEIGHT - 80, WIDTH, 80))

        # 全ての建物を描画
        for b in buildings:
            b.draw(display_surface)

        # テキスト表示 (英語フォントにフォールバックした場合も考慮した表記)
        intensity_str = f"{SEISMIC_INTENSITY:.1f}"
        txt_title = font_main.render(f"Intensity: {intensity_str}", True, (255, 100, 100) if SEISMIC_INTENSITY > 5 else (255, 255, 255))
        txt_help = font_sub.render(f"Tap +/- Buttons or Press Up/Down Keys", True, (200, 200, 200))
        
        display_surface.blit(txt_title, (30, 30))
        display_surface.blit(txt_help, (30, 80))

        # --- オンスクリーンボタンの描画 (半透明) ---
        btn_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        # プラスボタン
        pygame.draw.rect(btn_surface, (235, 60, 40, 230), btn_plus, border_radius=10)
        p_txt = font_main.render("+", True, (255, 255, 255))
        btn_surface.blit(p_txt, p_txt.get_rect(center=btn_plus.center))
        # マイナスボタン
        pygame.draw.rect(btn_surface, (15, 30, 80, 230), btn_minus, border_radius=10)
        m_txt = font_main.render("-", True, (255, 255, 255))
        btn_surface.blit(m_txt, m_txt.get_rect(center=btn_minus.center))
        
        display_surface.blit(btn_surface, (0, 0))

        # --- 最終的な画面出力 ---
        # display_surface を、カメラの揺れ分だけずらしてメインの screen に Blit する
        screen.fill((0, 0, 0))
        screen.blit(display_surface, (camera_shake_x, camera_shake_y))

        # 4. 画面更新とFPS管理
        pygame.display.flip()
        await asyncio.sleep(0) # pygbagで必須のブラウザフリーズ防止処理

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    asyncio.run(main())