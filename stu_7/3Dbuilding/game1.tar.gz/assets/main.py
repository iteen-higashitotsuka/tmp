import pygame
import math
import asyncio

# --- 初期設定 ---
WIDTH, HEIGHT = 1000, 600 # iPad等の画面比率に合わせ少し調整
FPS = 60

# --- 色 ---
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GRAY = (100, 100, 100)
DEEP_BLUE = (10, 10, 50)
BROWN = (139, 69, 19)
BUILD_COLOR_WALL = (0, 200, 255)
BUILD_COLOR_STAIR = (255, 200, 0)
TEXT_COLOR = (255, 255, 0)

# --- ワールド設定 ---
MAP_SIZE = 20
TILE_SIZE = 60
world_map = [[0 for _ in range(MAP_SIZE)] for _ in range(MAP_SIZE)]
for i in range(MAP_SIZE):
    world_map[0][i] = world_map[MAP_SIZE-1][i] = 1
    world_map[i][0] = world_map[i][MAP_SIZE-1] = 1

# --- レイキャスティング設定 ---
FOV = math.pi / 3
HALF_FOV = FOV / 2
NUM_RAYS = 120 # ブラウザでのパフォーマンスを考慮して調整
MAX_DEPTH = 1200
DELTA_ANGLE = FOV / NUM_RAYS
SCALE = WIDTH // NUM_RAYS
BUILD_RANGE = 2.5

async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Fortnite-like: Touch & Web Ready")
    clock = pygame.time.Clock()
    
    # pygbag環境ではシステムフォントが不安定なためデフォルトフォントを使用
    font = pygame.font.Font(None, 32)
    small_font = pygame.font.Font(None, 24)

    buildings = {}

    # プレイヤー設定
    player_x = MAP_SIZE * TILE_SIZE / 2
    player_y = MAP_SIZE * TILE_SIZE / 2
    player_angle = 0
    player_z = 0           
    player_speed = 4

    build_mode = 'wall'
    
    # --- タッチボタン設定 (iPad用) ---
    btn_up = pygame.Rect(100, HEIGHT - 180, 70, 70)
    btn_down = pygame.Rect(100, HEIGHT - 90, 70, 70)
    btn_left = pygame.Rect(20, HEIGHT - 90, 70, 70)
    btn_right = pygame.Rect(180, HEIGHT - 90, 70, 70)
    
    btn_build = pygame.Rect(WIDTH - 120, HEIGHT - 120, 100, 100)
    btn_mode = pygame.Rect(WIDTH - 120, HEIGHT - 240, 100, 80)
    
    active_touches = {} # マルチタッチ追跡用
    build_cooldown = 0

    def draw_3d_view():
        horizon_shift = player_z * (HEIGHT // 4)
        pygame.draw.rect(screen, DEEP_BLUE, (0, 0, WIDTH, HEIGHT // 2 + horizon_shift))
        pygame.draw.rect(screen, BROWN, (0, HEIGHT // 2 + horizon_shift, WIDTH, HEIGHT // 2 - horizon_shift))

        start_angle = player_angle - HALF_FOV
        for r in range(NUM_RAYS):
            angle = start_angle + r * DELTA_ANGLE
            sin_a, cos_a = math.sin(angle), math.cos(angle)
            
            for depth in range(1, MAX_DEPTH, 5):
                target_x = player_x + depth * cos_a
                target_y = player_y + depth * sin_a
                grid_x, grid_y = int(target_x // TILE_SIZE), int(target_y // TILE_SIZE)
                
                if 0 <= grid_x < MAP_SIZE and 0 <= grid_y < MAP_SIZE:
                    wall_type = 0
                    if world_map[grid_y][grid_x] == 1: wall_type = 1
                    elif (grid_x, grid_y) in buildings:
                        wall_type = 2 if buildings[(grid_x, grid_y)] == 'wall' else 3
                    
                    if wall_type > 0:
                        depth *= math.cos(player_angle - angle)
                        wall_height = (TILE_SIZE * HEIGHT) / (depth + 0.0001)
                        color_v = 255 / (1 + depth * depth * 0.00001)
                        
                        if wall_type == 1: color = (color_v, color_v, color_v)
                        elif wall_type == 2: color = (0, color_v * 0.7, color_v)
                        else: color = (color_v, color_v * 0.7, 0)

                        current_z_offset = player_z * wall_height 
                        wall_y = HEIGHT // 2 - wall_height // 2 + horizon_shift - current_z_offset
                        pygame.draw.rect(screen, color, (r * SCALE, wall_y, SCALE, wall_height))
                        break

    def do_build():
        target_x = player_x + math.cos(player_angle) * TILE_SIZE * BUILD_RANGE
        target_y = player_y + math.sin(player_angle) * TILE_SIZE * BUILD_RANGE
        grid_x, grid_y = int(target_x // TILE_SIZE), int(target_y // TILE_SIZE)
        
        if 0 < grid_x < MAP_SIZE-1 and 0 < grid_y < MAP_SIZE-1:
            if world_map[grid_y][grid_x] == 0 and (grid_x, grid_y) not in buildings:
                buildings[(grid_x, grid_y)] = build_mode

    # --- ゲームループ ---
    running = True
    while running:
        if build_cooldown > 0: build_cooldown -= 1

        move_fwd = move_bck = move_lft = move_rgt = False
        do_build_flag = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                
            # [キーボード操作]
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE: running = False
                if event.key == pygame.K_q: build_mode = 'wall'
                if event.key == pygame.K_e: build_mode = 'stair'
                if event.key == pygame.K_r: buildings.clear()
                if event.key == pygame.K_SPACE: do_build_flag = True

            # [マウス操作（PCデバッグ用）]
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    pos = event.pos
                    if btn_build.collidepoint(pos): do_build_flag = True
                    elif btn_mode.collidepoint(pos): build_mode = 'stair' if build_mode == 'wall' else 'wall'
                    elif not any(b.collidepoint(pos) for b in [btn_up, btn_down, btn_left, btn_right]):
                        do_build_flag = True # ボタン以外をクリックで建築

            if event.type == pygame.MOUSEMOTION and pygame.mouse.get_pressed()[0]:
                if event.pos[0] > WIDTH // 2 and not btn_build.collidepoint(event.pos) and not btn_mode.collidepoint(event.pos):
                    player_angle += event.rel[0] * 0.005 # 右半分ドラッグで視点移動

            # [タッチパネル操作（iPad/スマホ用）]
            if event.type == pygame.FINGERDOWN:
                fx, fy = event.x * WIDTH, event.y * HEIGHT
                active_touches[event.finger_id] = (fx, fy)
                
                if btn_build.collidepoint(fx, fy): do_build_flag = True
                elif btn_mode.collidepoint(fx, fy): build_mode = 'stair' if build_mode == 'wall' else 'wall'

            if event.type == pygame.FINGERMOTION:
                fx, fy = event.x * WIDTH, event.y * HEIGHT
                active_touches[event.finger_id] = (fx, fy)
                # 画面右半分をスワイプで視点移動
                if fx > WIDTH // 2 and not btn_build.collidepoint(fx, fy) and not btn_mode.collidepoint(fx, fy):
                    player_angle += event.dx * 2.0 # event.dxは0.0~1.0の正規化された移動量

            if event.type == pygame.FINGERUP:
                if event.finger_id in active_touches:
                    del active_touches[event.finger_id]

        # ---------------------------------------------
        # キーボードとタッチの入力統合
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w]: move_fwd = True
        if keys[pygame.K_s]: move_bck = True
        if keys[pygame.K_a]: move_lft = True
        if keys[pygame.K_d]: move_rgt = True
        if keys[pygame.K_LEFT]: player_angle -= 0.05
        if keys[pygame.K_RIGHT]: player_angle += 0.05

        for pos in active_touches.values():
            if btn_up.collidepoint(pos): move_fwd = True
            if btn_down.collidepoint(pos): move_bck = True
            if btn_left.collidepoint(pos): move_lft = True
            if btn_right.collidepoint(pos): move_rgt = True

        if do_build_flag and build_cooldown == 0:
            do_build()
            build_cooldown = 15

        # 移動計算
        new_x, new_y = player_x, player_y
        sin_p, cos_p = math.sin(player_angle), math.cos(player_angle)
        
        if move_fwd: new_x += player_speed * cos_p; new_y += player_speed * sin_p
        if move_bck: new_x -= player_speed * cos_p; new_y -= player_speed * sin_p
        if move_lft: new_x += player_speed * sin_p; new_y -= player_speed * cos_p
        if move_rgt: new_x -= player_speed * sin_p; new_y += player_speed * cos_p

        # 衝突判定
        grid_x, grid_y = int(new_x // TILE_SIZE), int(new_y // TILE_SIZE)
        if 0 <= grid_x < MAP_SIZE and 0 <= grid_y < MAP_SIZE:
            if world_map[grid_y][grid_x] == 0 and buildings.get((grid_x, grid_y)) != 'wall':
                player_x, player_y = new_x, new_y

        # 階段登り判定
        on_stair = (buildings.get((grid_x, grid_y)) == 'stair')
        target_z = 0.8 if on_stair else 0.0
        player_z += (target_z - player_z) * 0.15

        # --- 描画 ---
        screen.fill(BLACK)
        draw_3d_view()
        
        # 照準
        pygame.draw.circle(screen, WHITE, (WIDTH//2, HEIGHT//2), 2)
        
        # UIテキスト
        screen.blit(font.render(f"MODE: {build_mode.upper()}", True, TEXT_COLOR), (20, 20))
        screen.blit(small_font.render("Drag Right Screen to Look", True, WHITE), (WIDTH - 250, 20))

        # --- オンスクリーンボタンの描画 (半透明) ---
        ui_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        
        # D-PAD
        for btn, label in [(btn_up, "W"), (btn_down, "S"), (btn_left, "A"), (btn_right, "D")]:
            pygame.draw.rect(ui_surface, (100, 100, 100, 120), btn, border_radius=10)
            txt = font.render(label, True, WHITE)
            ui_surface.blit(txt, txt.get_rect(center=btn.center))
            
        # アクションボタン
        pygame.draw.rect(ui_surface, (200, 50, 50, 150), btn_build, border_radius=20)
        b_txt = font.render("BUILD", True, WHITE)
        ui_surface.blit(b_txt, b_txt.get_rect(center=btn_build.center))

        mode_color = (0, 150, 255, 150) if build_mode == 'wall' else (255, 150, 0, 150)
        pygame.draw.rect(ui_surface, mode_color, btn_mode, border_radius=10)
        m_txt = font.render("MODE", True, WHITE)
        ui_surface.blit(m_txt, m_txt.get_rect(center=btn_mode.center))

        screen.blit(ui_surface, (0, 0))
        
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0) # ブラウザのフリーズ防止（必須）

if __name__ == "__main__":
    asyncio.run(main())