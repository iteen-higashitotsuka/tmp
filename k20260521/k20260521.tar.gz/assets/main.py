import pygame
import math
import sys
import random
import array
import asyncio  # pygbag用にasyncioを追加

# Initialize / 初期化
pygame.init()
try:
    pygame.mixer.init(frequency=44100, size=-16, channels=1, buffer=512)
    audio_enabled = True
except:
    audio_enabled = False

# --- Constants / 定数 ---
WIDTH, HEIGHT = 800, 600
FPS = 60
ROAD_WIDTH = 2000
SEGMENT_LENGTH = 200
CAMERA_DEPTH = 1.0
DRAW_DISTANCE = 600
MAX_LAPS = 3

# Colors
C_SKY = (113, 197, 245)
C_GRASS_LIGHT = (16, 200, 16)
C_GRASS_DARK = (0, 154, 0)
C_ROAD_LIGHT = (107, 107, 107)
C_ROAD_DARK = (105, 105, 105)
C_RUMBLE_1 = (255, 255, 255)
C_RUMBLE_2 = (255, 0, 0)
C_FINISH = (0, 0, 0)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Ultimate City Racing - Red Shells & Street Trees!")
clock = pygame.time.Clock()

font_large = pygame.font.SysFont(None, 52)
small_font = pygame.font.SysFont(None, 24)
big_font = pygame.font.SysFont(None, 120)

#  タッチボタンの配置 (X, Y, 幅, 高さ) - iPadの親指で操作しやすい位置
BTN_LEFT = (20, 450, 100, 120)
BTN_RIGHT = (130, 450, 100, 120)
BTN_BRAKE = (550, 450, 100, 120)
BTN_GAS = (680, 450, 100, 120)
BTN_ITEM = (680, 300, 100, 120)

# --- Synthetic Sounds ---
def create_beep(freq, duration):
    if not audio_enabled: return None
    sample_rate = 44100
    n_samples = int(sample_rate * duration)
    buf = array.array('h', [0] * n_samples)
    for i in range(n_samples):
        t = float(i) / sample_rate
        buf[i] = int(16000 * math.sin(2 * math.pi * freq * t))
    return pygame.mixer.Sound(buffer=buf)

snd_warning = create_beep(880, 0.1) 
snd_hit = create_beep(150, 0.4)     

# --- Classes ---
class Segment:
    def __init__(self, index):
        self.index = index
        self.z = index * SEGMENT_LENGTH
        self.curve = 0
        self.y = 0  
        self.X = 0; self.Y = 0; self.W = 0; self.scale = 0
        self.scenery_left = None
        self.scenery_right = None

    def project(self, cam_x, cam_y, cam_z):
        self.scale = CAMERA_DEPTH / (self.z - cam_z) if self.z != cam_z else 0.0001
        self.X = (1 + self.scale * (-cam_x)) * WIDTH / 2
        self.Y = (1 - self.scale * (self.y - cam_y)) * HEIGHT / 2
        self.W = self.scale * ROAD_WIDTH * WIDTH / 2

class Car:
    def __init__(self, is_player=False, color=(255, 0, 0), max_speed=200):
        self.is_player = is_player
        self.z = 0; self.x = 0; self.speed = 0
        self.max_speed = max_speed
        self.color = color
        self.lap = 1
        self.finished = False; self.finish_time = 0
        self.items = [] 
        self.boost_timer = 0
        self.spin_timer = 0 

class Shell:
    def __init__(self, owner, target):
        self.z = owner.z + 400
        self.x = owner.x
        self.speed = owner.speed + 150 
        self.owner = owner
        self.target = target
        self.active = True

# --- Course Generation ---
segments = []
TRACK_LENGTH = 2800 

def add_curve(start, length, curve_strength):
    for i in range(start, start + length):
        if i < TRACK_LENGTH: segments[i].curve = curve_strength

for i in range(TRACK_LENGTH): segments.append(Segment(i))

# Curves 
add_curve(400, 100, 0.5); add_curve(600, 80, 0.2); add_curve(750, 150, 0.4)
add_curve(1000, 80, -0.6); add_curve(1200, 100, 0.3); add_curve(1400, 150, -0.4)
add_curve(1650, 120, 0.5); add_curve(2000, 120, 2.0); add_curve(2250, 120, -2.0)
add_curve(2500, 100, 1.6)  

track_max_z = TRACK_LENGTH * SEGMENT_LENGTH

# Scenery
building_types = ['building', 'house', 'hospital', 'library']
for i in range(TRACK_LENGTH):
    if i % 5 == 0:
        segments[i].scenery_left = 'tree'
        segments[i].scenery_right = 'tree'
    if i % 12 == 0: segments[i].scenery_left = random.choice(building_types)
    if i % 14 == 0: segments[i].scenery_right = random.choice(building_types)

# --- Map Data ---
minimap_points = [
    (150, 130), (50, 130), (20, 120), (20, 100), (30, 80), 
    (50, 70), (80, 50), (100, 30), (120, 20), (140, 40), 
    (110, 60), (120, 80), (140, 100), (160, 110)
]
total_map_len = sum(math.hypot(minimap_points[(i+1)%len(minimap_points)][0] - minimap_points[i][0], 
                               minimap_points[(i+1)%len(minimap_points)][1] - minimap_points[i][1]) for i in range(len(minimap_points)))

def get_minimap_pos(pct):
    target = (pct % 1.0) * total_map_len; curr = 0
    for i in range(len(minimap_points)):
        p1 = minimap_points[i]; p2 = minimap_points[(i+1)%len(minimap_points)]
        d = math.hypot(p2[0]-p1[0], p2[1]-p1[1])
        if curr + d >= target:
            r = (target - curr) / d
            return int(p1[0] + (p2[0]-p1[0])*r), int(p1[1] + (p2[1]-p1[1])*r)
        curr += d
    return minimap_points[0]

# --- Drawing Functions ---
def draw_item_icon(surface, x, y, type_name, scale=1.0):
    if type_name == "MUSHROOM":
        pygame.draw.ellipse(surface, (250, 240, 220), (x+30*scale, y+40*scale, 40*scale, 50*scale))
        pygame.draw.ellipse(surface, (220, 20, 20), (x, y, 100*scale, 60*scale))
        for sx, sy in [(20,30), (50,15), (80,30)]: pygame.draw.circle(surface, (255, 255, 255), (x+sx*scale, y+sy*scale), 12*scale)
        for ex in [40, 54]: pygame.draw.ellipse(surface, (0, 0, 0), (x+ex*scale, y+55*scale, 6*scale, 15*scale))
    elif type_name == "RED_SHELL":
        pygame.draw.ellipse(surface, (200, 20, 20), (x+10*scale, y+10*scale, 80*scale, 70*scale))
        pygame.draw.ellipse(surface, (255, 255, 255), (x+10*scale, y+10*scale, 80*scale, 70*scale), max(1, int(4*scale)))
        pygame.draw.arc(surface, (0,0,0), (x+20*scale, y+20*scale, 60*scale, 50*scale), 0, 3.14, int(2*scale))
        pygame.draw.rect(surface, (250, 240, 220), (x+15*scale, y+70*scale, 70*scale, 15*scale), border_radius=5)

def draw_scenery(surface, seg, type_name, is_left):
    if seg.scale < 0.0005: return 
    sw = seg.scale * 150000; sh = seg.scale * 300000
    offset_dist = 1.1 if type_name == 'tree' else 1.8
    offset = seg.W * offset_dist + sw * 0.5 
    base_x = seg.X - offset if is_left else seg.X + offset
    base_y = seg.Y
    
    if type_name == 'tree':
        t_sw, t_sh = sw * 0.4, sh * 0.5
        pygame.draw.rect(surface, (100, 70, 40), (base_x - t_sw*0.1, base_y - t_sh*0.3, t_sw*0.2, t_sh*0.3))
        pygame.draw.circle(surface, (34, 139, 34), (int(base_x), int(base_y - t_sh*0.4)), int(t_sw*0.6))
    elif type_name == 'building':
        b_sh = sh * 1.5 
        pygame.draw.rect(surface, (100, 110, 130), (base_x - sw/2, base_y - b_sh, sw, b_sh))
        win_w, win_h = sw * 0.15, b_sh * 0.05
        for row in range(10):
            for col in [-1, 0, 1]: pygame.draw.rect(surface, (255, 255, 200), (base_x + col*sw*0.3 - win_w/2, base_y - b_sh*0.95 + row*b_sh*0.09, win_w, win_h))
    elif type_name == 'house':
        h_sh = sh * 0.6
        pygame.draw.rect(surface, (240, 230, 210), (base_x - sw/2, base_y - h_sh, sw, h_sh))
        pygame.draw.polygon(surface, (200, 60, 60), [(base_x - sw*0.6, base_y - h_sh), (base_x + sw*0.6, base_y - h_sh), (base_x, base_y - h_sh - h_sh*0.6)])
    elif type_name == 'hospital':
        h_sw, h_sh = sw * 1.2, sh * 0.8
        pygame.draw.rect(surface, (255, 250, 250), (base_x - h_sw/2, base_y - h_sh, h_sw, h_sh))
        pygame.draw.rect(surface, (220, 20, 20), (base_x - h_sw*0.08, base_y - h_sh*0.8, h_sw*0.16, h_sw*0.4))
        pygame.draw.rect(surface, (220, 20, 20), (base_x - h_sw*0.2, base_y - h_sh*0.8 + h_sw*0.12, h_sw*0.4, h_sw*0.16))
    elif type_name == 'library':
        l_sw, l_sh = sw * 1.5, sh * 0.6
        pygame.draw.rect(surface, (200, 180, 150), (base_x - l_sw/2, base_y - l_sh, l_sw, l_sh))
        pygame.draw.polygon(surface, (150, 130, 100), [(base_x - l_sw*0.55, base_y - l_sh), (base_x + l_sw*0.55, base_y - l_sh), (base_x, base_y - l_sh - l_sh*0.5)])

def draw_player_car(surface, steering_offset, boost, spin_timer):
    car_w, car_h = 240, 120
    car_x = WIDTH // 2 + (steering_offset * 50)
    car_y = HEIGHT - 140
    
    if spin_timer > 0:
        scale_x = math.cos(spin_timer * 0.3)
        car_w = max(10, int(car_w * abs(scale_x)))
    
    pygame.draw.rect(surface, (30, 30, 30), (car_x - car_w//2 - 10, car_y + car_h - 40, max(10, 40*car_w//240), 50), border_radius=10)
    pygame.draw.rect(surface, (30, 30, 30), (car_x + car_w//2 - 30*car_w//240, car_y + car_h - 40, max(10, 40*car_w//240), 50), border_radius=10)
    pygame.draw.rect(surface, (0, 0, 0), (car_x - car_w//2 - 4, car_y - 4, car_w + 8, car_h + 8), border_radius=20)
    pygame.draw.rect(surface, (220, 30, 30), (car_x - car_w//2, car_y, car_w, car_h), border_radius=20)
    pygame.draw.rect(surface, (50, 150, 255), (car_x - car_w//4, car_y - 20, car_w//2, 60), border_radius=15)
    
    if boost > 0 and spin_timer <= 0:
        pygame.draw.polygon(surface, (255, random.randint(100, 200), 0), [
            (car_x - 30*car_w//240, car_y + car_h), (car_x + 30*car_w//240, car_y + car_h), (car_x, car_y + car_h + random.randint(40, 80))
        ])

#  タッチボタン描画関数
def draw_touch_btn(surface, rect, text, is_pressed):
    alpha = 150 if is_pressed else 60
    s = pygame.Surface((rect[2], rect[3]), pygame.SRCALPHA)
    s.fill((255, 255, 255, alpha))
    pygame.draw.rect(s, (255, 255, 255, 200), s.get_rect(), 3, border_radius=15)
    surface.blit(s, (rect[0], rect[1]))
    
    txt_surf = small_font.render(text, True, (0, 0, 0) if is_pressed else (255, 255, 255))
    txt_rect = txt_surf.get_rect(center=(rect[0] + rect[2]//2, rect[1] + rect[3]//2))
    surface.blit(txt_surf, txt_rect)

# --- Game Logic ---
def reset_game():
    global player, cpus, all_cars, crystals, active_shells, state, start_ticks, countdown_time
    player = Car(is_player=True, max_speed=260)
    
    cpus = []
    colors = [(200, 200, 200), (50, 200, 50), (50, 50, 200), (200, 200, 50), (200, 50, 200)]
    for i in range(5):
        cpu = Car(color=colors[i], max_speed=245 + random.randint(-10, 15)) 
        cpu.z = random.randint(500, 2000); cpu.x = random.uniform(-0.6, 0.6)
        cpus.append(cpu)
        
    all_cars = [player] + cpus
    active_shells = []
    
    crystals = []
    for i in range(5): crystals.append({'z': (track_max_z // 6) * (i + 1), 'x': random.uniform(-0.8, 0.8), 'cooldown': 0})
    block_z = 380000 
    for x in [-0.8, -0.4, 0.0, 0.4, 0.8]: crystals.append({'z': block_z, 'x': x, 'cooldown': 0})

    state = "COUNTDOWN"
    start_ticks = pygame.time.get_ticks()
    countdown_time = 3

#  pygbag用に全体を非同期関数(main)で包む
async def main():
    global warning_blink
    
    reset_game()
    running = True
    warning_blink = 0
    
    touches = {} # マルチタッチを管理する辞書
    prev_is_item = False
    prev_is_restart = False

    while running:
        current_ticks = pygame.time.get_ticks()
        warning_active = False 
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT: 
                running = False
            
            #  スマホ・タブレットのタッチ（マルチタッチ対応）
            elif event.type == pygame.FINGERDOWN or event.type == pygame.FINGERMOTION:
                touches[event.finger_id] = (event.x * WIDTH, event.y * HEIGHT)
            elif event.type == pygame.FINGERUP:
                if event.finger_id in touches:
                    del touches[event.finger_id]
                    
            #  PCのマウスクリック（テスト用）
            elif event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.MOUSEMOTION:
                if pygame.mouse.get_pressed()[0]:
                    touches['mouse'] = pygame.mouse.get_pos()
            elif event.type == pygame.MOUSEBUTTONUP:
                if 'mouse' in touches:
                    del touches['mouse']

        #  タッチ判定の処理
        t_up = t_down = t_left = t_right = t_item = t_restart = False
        
        def in_rect(pt, r):
            return r[0] <= pt[0] <= r[0]+r[2] and r[1] <= pt[1] <= r[1]+r[3]
            
        for pt in touches.values():
            if in_rect(pt, BTN_LEFT): t_left = True
            if in_rect(pt, BTN_RIGHT): t_right = True
            if in_rect(pt, BTN_GAS): t_up = True
            if in_rect(pt, BTN_BRAKE): t_down = True
            if in_rect(pt, BTN_ITEM): t_item = True
            if state == "FINISHED": t_restart = True # ゴール後は画面タップでリスタート

        keys = pygame.key.get_pressed()
        
        # キーボード入力とタッチ入力を統合
        is_up = keys[pygame.K_UP] or t_up
        is_down = keys[pygame.K_DOWN] or t_down
        is_left = keys[pygame.K_LEFT] or t_left
        is_right = keys[pygame.K_RIGHT] or t_right
        is_item = keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT] or t_item
        is_restart = keys[pygame.K_r] or t_restart

        #  アイテム使用の判定（押しっぱなしで連続発射しないように制御）
        if is_item and not prev_is_item and state == "RACING":
            if len(player.items) > 0 and player.boost_timer <= 0 and player.spin_timer <= 0:
                used_item = player.items.pop(0) 
                if used_item == "MUSHROOM":
                    player.boost_timer = FPS * 3 
                elif used_item == "RED_SHELL":
                    target = None; min_dist = 9999999
                    for c in cpus:
                        dist = (c.z - player.z) % track_max_z
                        if 0 < dist < min_dist: min_dist = dist; target = c
                    if target: active_shells.append(Shell(player, target))
        prev_is_item = is_item

        # リスタートの判定
        if is_restart and not prev_is_restart:
            reset_game()
        prev_is_restart = is_restart


        # --- ゲームの進行処理 ---
        if state == "COUNTDOWN":
            elapsed = (current_ticks - start_ticks) / 1000.0
            countdown_time = 3 - int(elapsed)
            if countdown_time <= 0: state = "RACING"; start_ticks = pygame.time.get_ticks()
                
        elif state == "RACING":
            if player.spin_timer > 0:
                player.speed = 0
                player.spin_timer -= 1
            else:
                current_max = player.max_speed * 2 if player.boost_timer > 0 else player.max_speed
                if player.boost_timer > 0: player.boost_timer -= 1

                if is_up: player.speed += 4 if player.boost_timer > 0 else 2
                elif is_down: player.speed -= 5
                else: player.speed -= 1 
                
                player.speed = max(0, min(player.speed, current_max))

                base_seg = segments[int(player.z / SEGMENT_LENGTH) % TRACK_LENGTH]
                centrifugal = player.speed * base_seg.curve * 0.0003
                
                steer_power = 0.09 * (player.speed / player.max_speed) if player.max_speed > 0 else 0
                if is_left: player.x -= steer_power
                if is_right: player.x += steer_power
                player.x -= centrifugal
                
                if abs(player.x) > 1.2 and player.boost_timer <= 0: player.speed = max(50, player.speed - 5)

            player.z += player.speed

            for car in all_cars:
                track_z = car.z % track_max_z
                for c in crystals:
                    if c['cooldown'] > 0: continue
                    if abs(track_z - c['z']) < 800 and abs(car.x - c['x']) < 0.4:
                        c['cooldown'] = FPS * 5
                        new_item = random.choice(["MUSHROOM", "RED_SHELL"])
                        if car.is_player:
                            if len(player.items) < 2: player.items.append(new_item)
                        else:
                            if len(car.items) < 2: car.items.append(new_item)

                if not car.is_player:
                    if car.spin_timer > 0:
                        car.speed = 0; car.spin_timer -= 1
                    else:
                        if len(car.items) > 0:
                            it = car.items.pop(0)
                            if it == "MUSHROOM": car.boost_timer = FPS * 3
                            elif it == "RED_SHELL":
                                t = player if ((player.z - car.z)%track_max_z < 30000) else None
                                if t: active_shells.append(Shell(car, t))

                        cpu_max = car.max_speed * 1.8 if car.boost_timer > 0 else car.max_speed
                        if car.boost_timer > 0: car.boost_timer -= 1
                        car.speed = cpu_max
                        cpu_seg = segments[int(car.z / SEGMENT_LENGTH) % TRACK_LENGTH]
                        car.x = max(-0.9, min(0.9, car.x - car.speed * cpu_seg.curve * 0.00025))
                        
                    car.z += car.speed

            for sh in active_shells[:]:
                sh.z += sh.speed
                sh.x += (sh.target.x - sh.x) * 0.05
                
                dist_to_target = (sh.target.z - sh.z) % track_max_z
                if dist_to_target < 800 and abs(sh.target.x - sh.x) < 0.4:
                    sh.target.spin_timer = FPS * 2 
                    if snd_hit: snd_hit.play()
                    active_shells.remove(sh)
                elif dist_to_target > 50000: 
                    active_shells.remove(sh)
                    
                if sh.target == player and dist_to_target < 10000:
                    warning_active = True
                    
            if warning_active:
                warning_blink += 1
                if warning_blink % 10 == 0 and snd_warning: snd_warning.play()
            else: warning_blink = 0

            for car in all_cars:
                if car.z >= track_max_z:
                    car.z -= track_max_z; car.lap += 1
                    if car.is_player and car.lap > MAX_LAPS:
                        car.finished = True; car.finish_time = current_ticks - start_ticks
                        state = "FINISHED"

        for c in crystals:
            if c['cooldown'] > 0: c['cooldown'] -= 1

        all_cars.sort(key=lambda c: c.lap * track_max_z + c.z, reverse=True)
        player_rank = all_cars.index(player) + 1

        # --- Draw ---
        sky_col = (150, 100, 255) if player.boost_timer > 0 else C_SKY
        screen.fill(sky_col)
        grass_base = (0, 200, 100) if player.boost_timer > 0 else C_GRASS_LIGHT
        pygame.draw.rect(screen, grass_base, (0, HEIGHT//2, WIDTH, HEIGHT//2))

        cam_z = player.z - 300; cam_y = 1200; cam_x = player.x * ROAD_WIDTH
        start_pos = int(cam_z / SEGMENT_LENGTH)
        dx = 0; curve_x = 0
        
        rendered_segments = []
        for i in range(start_pos, start_pos + DRAW_DISTANCE):
            idx = i % TRACK_LENGTH; seg = segments[idx]
            curve_x += dx; dx += seg.curve

            z_diff = seg.z - cam_z
            if i >= TRACK_LENGTH and i != start_pos: z_diff += track_max_z
            if z_diff <= 0: continue
                
            seg.scale = CAMERA_DEPTH / z_diff
            seg.X = (1 + seg.scale * (curve_x - cam_x)) * WIDTH / 2
            seg.Y = (1 - seg.scale * (seg.y - cam_y)) * HEIGHT / 2
            seg.W = seg.scale * ROAD_WIDTH * WIDTH / 2
            
            if seg.Y >= HEIGHT: continue
            rendered_segments.append(seg)

        for i in range(len(rendered_segments) - 1, 0, -1):
            seg = rendered_segments[i]; prev = rendered_segments[i-1]
            if seg.Y >= prev.Y: continue

            is_light = (seg.index // 3) % 2 == 0
            grass_col = C_GRASS_LIGHT if is_light else C_GRASS_DARK
            road_col = C_ROAD_LIGHT if is_light else C_ROAD_DARK
            rumble_col = C_RUMBLE_1 if is_light else C_RUMBLE_2
            
            if player.boost_timer > 0: grass_col = (random.randint(0,50), random.randint(150,255), random.randint(50,150))
            if seg.index <= 3: road_col = C_FINISH if (seg.index % 2) == 0 else C_RUMBLE_1

            pygame.draw.rect(screen, grass_col, (0, prev.Y, WIDTH, seg.Y - prev.Y))
            pygame.draw.polygon(screen, rumble_col, [(prev.X-prev.W*1.2, prev.Y), (seg.X-seg.W*1.2, seg.Y), (seg.X+seg.W*1.2, seg.Y), (prev.X+prev.W*1.2, prev.Y)])
            pygame.draw.polygon(screen, road_col, [(prev.X-prev.W, prev.Y), (seg.X-seg.W, seg.Y), (seg.X+seg.W, seg.Y), (prev.X+prev.W, prev.Y)])
            if is_light: pygame.draw.polygon(screen, (255, 255, 255), [(prev.X-prev.W*0.05, prev.Y), (seg.X-seg.W*0.05, seg.Y), (seg.X+seg.W*0.05, seg.Y), (prev.X+prev.W*0.05, prev.Y)])
                
            if prev.scenery_left: draw_scenery(screen, prev, prev.scenery_left, True)
            if prev.scenery_right: draw_scenery(screen, prev, prev.scenery_right, False)

        visible_objects = []
        for cpu in cpus:
            dist = cpu.z - cam_z
            if dist < 0: dist += track_max_z
            if 0 < dist < DRAW_DISTANCE * SEGMENT_LENGTH: visible_objects.append((dist, 'cpu', cpu))
                
        for c in crystals:
            if c['cooldown'] <= 0:
                dist = c['z'] - (cam_z % track_max_z)
                if dist < 0: dist += track_max_z
                if 0 < dist < DRAW_DISTANCE * SEGMENT_LENGTH: visible_objects.append((dist, 'crystal', c))
                
        for sh in active_shells:
            dist = sh.z - cam_z
            if dist < 0: dist += track_max_z
            if 0 < dist < DRAW_DISTANCE * SEGMENT_LENGTH: visible_objects.append((dist, 'shell', sh))

        visible_objects.sort(key=lambda x: x[0], reverse=True)

        for dist, obj_type, obj in visible_objects:
            obj_seg_idx = int((cam_z + dist) / SEGMENT_LENGTH) % TRACK_LENGTH
            seg = segments[obj_seg_idx]
            
            if seg.scale > 0:
                if obj_type == 'cpu':
                    cpu = obj
                    car_w, car_h = seg.scale * 80000, seg.scale * 40000
                    car_x = seg.X + (seg.scale * cpu.x * ROAD_WIDTH * WIDTH / 2)
                    car_y = seg.Y - car_h
                    
                    if cpu.spin_timer > 0:
                        scale_x = math.cos(cpu.spin_timer * 0.3)
                        car_w = max(5, int(car_w * abs(scale_x)))

                    pygame.draw.rect(screen, (0, 0, 0), (car_x - car_w//2 - 2, car_y - 2, car_w + 4, car_h + 4))
                    pygame.draw.rect(screen, cpu.color, (car_x - car_w/2, car_y, car_w, car_h))
                    if cpu.boost_timer > 0 and cpu.spin_timer <= 0: pygame.draw.rect(screen, (255, 100, 0), (car_x - car_w/2, car_y + car_h, car_w, car_h*0.5))
                
                elif obj_type == 'crystal':
                    c = obj
                    c_w = seg.scale * 200000; c_h = seg.scale * 200000 
                    c_x = seg.X + (seg.scale * c['x'] * ROAD_WIDTH * WIDTH / 2)
                    c_y = seg.Y - c_h - (math.sin(current_ticks/200) * seg.scale * 30000)
                    points = [(c_x, c_y), (c_x + c_w/2, c_y + c_h/2), (c_x, c_y + c_h), (c_x - c_w/2, c_y + c_h/2)]
                    pygame.draw.polygon(screen, (0, 255, 255), points)
                    pygame.draw.polygon(screen, (255, 255, 255), points, max(1, int(seg.scale*4000)))
                    if seg.scale > 0.003: 
                        q_surf = small_font.render("?", True, (0, 0, 0))
                        screen.blit(pygame.transform.scale(q_surf, (int(c_w*0.3), int(c_h*0.5))), (c_x - c_w*0.15, c_y + c_h*0.25))
                        
                elif obj_type == 'shell':
                    sh = obj
                    sh_w = seg.scale * 60000; sh_h = seg.scale * 50000
                    sh_x = seg.X + (seg.scale * sh.x * ROAD_WIDTH * WIDTH / 2)
                    sh_y = seg.Y - sh_h
                    pygame.draw.ellipse(screen, (200, 20, 20), (sh_x - sh_w//2, sh_y, sh_w, sh_h))
                    pygame.draw.ellipse(screen, (255, 255, 255), (sh_x - sh_w//2, sh_y, sh_w, sh_h), max(1, int(seg.scale*3000)))

        if state != "COUNTDOWN" or countdown_time <= 0:
            steer_anim = -1 if is_left else 1 if is_right else 0
            draw_player_car(screen, steer_anim, player.boost_timer, player.spin_timer)

        if warning_active and warning_blink % 20 < 10:
            warn_txt = font_large.render("! RED SHELL APPROACHING !", True, (255, 0, 0))
            screen.blit(warn_txt, (WIDTH//2 - warn_txt.get_width()//2, HEIGHT//2 + 50))

        controls_text = "CONTROLS: Keyboard OR On-Screen Buttons"
        ctrl_surface = small_font.render(controls_text, True, (255, 255, 255))
        ctrl_x = WIDTH // 2 - ctrl_surface.get_width() // 2
        pygame.draw.rect(screen, (0, 0, 0, 160), (ctrl_x - 5, 5, ctrl_surface.get_width() + 10, ctrl_surface.get_height() + 10), border_radius=5)
        screen.blit(ctrl_surface, (ctrl_x, 10))

        for idx in range(2):
            box_rect = (20 + (idx * 110), 20, 100, 100)
            pygame.draw.rect(screen, (0, 0, 0, 128), box_rect, border_radius=15)
            pygame.draw.rect(screen, (255, 255, 255), box_rect, 4, border_radius=15)
            if len(player.items) > idx: draw_item_icon(screen, box_rect[0] + 10, box_rect[1] + 15, player.items[idx], scale=0.8)

        if player.boost_timer > 0:
            boost_txt = font_large.render("BOOST!", True, (255, 255, 0))
            screen.blit(boost_txt, (20, 130))

        time_ms = current_ticks - start_ticks if state == "RACING" else (player.finish_time if state == "FINISHED" else 0)
        if state == "COUNTDOWN": time_ms = 0
        minutes = time_ms // 60000; seconds = (time_ms % 60000) // 1000; ms = (time_ms % 1000) // 10

        info_texts = [f"POS: {player_rank} / 6", f"LAP: {min(player.lap, MAX_LAPS)} / {MAX_LAPS}", f"TIME: {minutes:02}:{seconds:02}.{ms:02}"]
        start_y = HEIGHT - 150
        for i, text in enumerate(info_texts):
            surface = font_large.render(text, True, (255, 255, 255)); shadow = font_large.render(text, True, (0, 0, 0))
            screen.blit(shadow, (23, start_y + i * 45 + 3)); screen.blit(surface, (20, start_y + i * 45))

        map_offset_x, map_offset_y = WIDTH - 200, 20
        pygame.draw.rect(screen, (0, 0, 0, 160), (map_offset_x, map_offset_y, 180, 160), border_radius=10)
        drawn_map_points = [(p[0] + map_offset_x, p[1] + map_offset_y) for p in minimap_points]
        pygame.draw.lines(screen, (255, 255, 255), True, drawn_map_points, 3)

        for car in all_cars:
            progress = (car.z % track_max_z) / track_max_z
            mx, my = get_minimap_pos(progress)
            pygame.draw.circle(screen, (255, 255, 0) if car.is_player else car.color, (mx+map_offset_x, my+map_offset_y), 6 if car.is_player else 4)

        if state == "COUNTDOWN" or state == "FINISHED":
            text = str(countdown_time) if state == "COUNTDOWN" and countdown_time > 0 else "GO!" if state == "COUNTDOWN" else "GOAL!"
            color = (255, 50, 50) if state == "COUNTDOWN" and countdown_time > 0 else (50, 255, 50) if state == "COUNTDOWN" else (255, 215, 0)
            surface = big_font.render(text, True, color); shadow = big_font.render(text, True, (0, 0, 0))
            text_x, text_y = WIDTH//2 - surface.get_width()//2, HEIGHT//2 - 100
            screen.blit(shadow, (text_x + 5, text_y + 5)); screen.blit(surface, (text_x, text_y))

        #  UIの上にタッチボタンを描画
        draw_touch_btn(screen, BTN_LEFT, "<", is_left)
        draw_touch_btn(screen, BTN_RIGHT, ">", is_right)
        draw_touch_btn(screen, BTN_BRAKE, "BRAKE", is_down)
        draw_touch_btn(screen, BTN_GAS, "GAS", is_up)
        draw_touch_btn(screen, BTN_ITEM, "ITEM", is_item)

        pygame.display.flip()
        clock.tick(FPS)
        
        #  pygbagで動かすための必須処理（ブラウザに制御を返す）
        await asyncio.sleep(0) 

#  プログラムの起動処理をasyncio.runに変更
if __name__ == "__main__":
    asyncio.run(main())