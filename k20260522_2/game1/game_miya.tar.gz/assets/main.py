import pygame
import random
import sys
import asyncio
import urllib.request  # フォントダウンロード用に追加
import io              # メモリ上でファイルを扱う用に追加

# --- 初期設定 ---
pygame.init()
WIDTH, HEIGHT = 1280, 720
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("2人対戦 的あてバトル！ - iPad Web版")
clock = pygame.time.Clock()

# --- 【修正】日本語フォントをWebから読み込む処理 ---
print("日本語フォントをダウンロード中...")
try:
    # Google Fonts から軽量な「Noto Sans JP」のフォントファイルを引っ張ってきます
    font_url = "https://github.com/googlefonts/noto-fonts/raw/main/hinted/ttf/NotoSans/NotoSans-Bold.ttf"
    # ※もし漢字も細かく表示したい場合は、日本語対応の以下URLに差し替えてください（少しロード時間が延びます）
    # font_url = "https://raw.githubusercontent.com/shindome/Noto-Sans-JP-Grid/master/fonts/NotoSansJP-Bold.ttf"
    
    response = urllib.request.urlopen(font_url)
    font_data = io.BytesIO(response.read())
    
    # メモリ上のフォントファイルからPygame用フォントを作成
    font = pygame.font.Font(font_data, 30)
    large_font = pygame.font.Font(font_data, 70)
    print("フォントの読み込みに成功しました！")
except Exception as e:
    print(f"フォント読み込み失敗: {e}。システムフォントで代用します。")
    font = pygame.font.SysFont("Arial", 30, bold=True)
    large_font = pygame.font.SysFont("Arial", 70, bold=True)

# カラー定義
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 50, 50)
BLUE = (50, 50, 255)
YELLOW = (255, 255, 0)
GREEN = (0, 255, 0)
GRAY = (100, 100, 100)

# ゲーム定数
MAX_TARGETS = 25
CHARGE_MAX = 100
PLAYER_SPEED = 8

class Player:
    def __init__(self, x, color, shoot_key, left_key, right_key, name):
        self.rect = pygame.Rect(x, HEIGHT - 200, 60, 20)
        self.color = color
        self.shoot_key = shoot_key
        self.left_key = left_key
        self.right_key = right_key
        self.name = name
        self.score = 0
        self.charge = 0
        self.is_charging = False
        self.bullets = []

    def update(self, keys, touch_left, touch_right, touch_shoot):
        move_left = keys[self.left_key] or touch_left
        move_right = keys[self.right_key] or touch_right
        shoot_active = keys[self.shoot_key] or touch_shoot

        if move_left and self.rect.left > 0:
            self.rect.x -= PLAYER_SPEED
        if move_right and self.rect.right < WIDTH:
            self.rect.x += PLAYER_SPEED

        if shoot_active:
            self.is_charging = True
            if self.charge < CHARGE_MAX:
                self.charge += 2
        else:
            if self.is_charging:
                self.fire()
                self.is_charging = False
                self.charge = 0

        for b in self.bullets[:]:
            b['rect'].y -= 10
            if b['rect'].bottom < 0:
                self.bullets.remove(b)

    def fire(self):
        power = self.charge
        bullet_rect = pygame.Rect(self.rect.centerx - 5, self.rect.top, 10, 20)
        self.bullets.append({'rect': bullet_rect, 'power': power})

    def draw(self):
        pygame.draw.rect(screen, self.color, self.rect)
        if self.is_charging:
            gauge_rect = pygame.Rect(self.rect.x, self.rect.bottom + 5, self.charge * 0.6, 5)
            pygame.draw.rect(screen, YELLOW, gauge_rect)
        for b in self.bullets:
            color = self.color if b['power'] >= 50 else GRAY
            pygame.draw.rect(screen, color, b['rect'])

class Target:
    def __init__(self):
        self.reset()

    def reset(self):
        self.rect = pygame.Rect(random.randint(50, WIDTH-50), random.randint(80, 350), 40, 40)

def draw_virtual_pads():
    # P1用ボタン (画面左下)
    pygame.draw.rect(screen, BLUE, (30, 560, 100, 100), 2, border_radius=15)
    pygame.draw.rect(screen, BLUE, (150, 560, 100, 100), 2, border_radius=15)
    pygame.draw.rect(screen, BLUE, (270, 560, 140, 100), 2, border_radius=15)
    
    # P2用ボタン (画面右下)
    pygame.draw.rect(screen, RED, (WIDTH - 410, 560, 140, 100), 2, border_radius=15)
    pygame.draw.rect(screen, RED, (WIDTH - 250, 560, 100, 100), 2, border_radius=15)
    pygame.draw.rect(screen, RED, (WIDTH - 130, 560, 100, 100), 2, border_radius=15)

    # 【修正】英語メインにしつつ、日本語が化けないフォントで描画
    p1_left_lbl = font.render("A <", True, BLUE)
    p1_right_lbl = font.render("D >", True, BLUE)
    p1_shoot_lbl = font.render("0 FIRE", True, BLUE)
    
    p2_shoot_lbl = font.render("SP FIRE", True, RED)
    p2_left_lbl = font.render("< Left", True, RED)
    p2_right_lbl = font.render("> Right", True, RED)

    screen.blit(p1_left_lbl, (30 + 50 - p1_left_lbl.get_width()//2, 560 + 50 - p1_left_lbl.get_height()//2))
    screen.blit(p1_right_lbl, (150 + 50 - p1_right_lbl.get_width()//2, 560 + 50 - p1_right_lbl.get_height()//2))
    screen.blit(p1_shoot_lbl, (270 + 70 - p1_shoot_lbl.get_width()//2, 560 + 50 - p1_shoot_lbl.get_height()//2))

    screen.blit(p2_shoot_lbl, (WIDTH - 410 + 70 - p2_shoot_lbl.get_width()//2, 560 + 50 - p2_shoot_lbl.get_height()//2))
    screen.blit(p2_left_lbl, (WIDTH - 250 + 50 - p2_left_lbl.get_width()//2, 560 + 50 - p2_left_lbl.get_height()//2))
    screen.blit(p2_right_lbl, (WIDTH - 130 + 50 - p2_right_lbl.get_width()//2, 560 + 50 - p2_right_lbl.get_height()//2))

    pygame.draw.line(screen, GRAY, (0, 520), (WIDTH, 520), 2)

async def main():
    p1 = Player(WIDTH//4, BLUE, pygame.K_0, pygame.K_a, pygame.K_d, "P1")
    p2 = Player(WIDTH*3//4, RED, pygame.K_SPACE, pygame.K_LEFT, pygame.K_RIGHT, "P2")
    
    target = Target()
    target_count = 1
    game_over = False

    while True:
        screen.fill(BLACK)
        keys = pygame.key.get_pressed()

        p1_touch_left, p1_touch_right, p1_touch_shoot = False, False, False
        p2_touch_left, p2_touch_right, p2_touch_shoot = False, False, False

        touch_list = []
        if pygame.mouse.get_pressed()[0]:
            touch_list.append(pygame.mouse.get_pos())
        
        for pos in touch_list:
            tx, ty = pos
            if 560 <= ty <= 660:
                if 30 <= tx <= 130: p1_touch_left = True
                if 150 <= tx <= 250: p1_touch_right = True
                if 270 <= tx <= 410: p1_touch_shoot = True
                if (WIDTH - 410) <= tx <= (WIDTH - 270): p2_touch_shoot = True
                if (WIDTH - 250) <= tx <= (WIDTH - 150): p2_touch_left = True
                if (WIDTH - 130) <= tx <= (WIDTH - 30):  p2_touch_right = True

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            
            if game_over and event.type == pygame.MOUSEBUTTONDOWN:
                p1.score, p2.score = 0, 0
                p1.bullets.clear()
                p2.bullets.clear()
                target.reset()
                target_count = 1
                game_over = False

        if not game_over:
            p1.update(keys, p1_touch_left, p1_touch_right, p1_touch_shoot)
            p2.update(keys, p2_touch_left, p2_touch_right, p2_touch_shoot)

            for p in [p1, p2]:
                for b in p.bullets[:]:
                    if b['rect'].colliderect(target.rect) and b['power'] >= 50:
                        p.score += 1
                        p.bullets.remove(b)
                        if target_count < MAX_TARGETS:
                            target.reset()
                            target_count += 1
                        else:
                            game_over = True

            p1.draw()
            p2.draw()
            if not game_over:
                pygame.draw.ellipse(screen, GREEN, target.rect)
                pygame.draw.ellipse(screen, WHITE, target.rect, 2)
            
            draw_virtual_pads()
        else:
            if p1.score > p2.score:
                result_text = "PLAYER 1 WIN!"
            elif p2.score > p1.score:
                result_text = "PLAYER 2 WIN!"
            else:
                result_text = "DRAW!"
            
            res_surf = large_font.render(result_text, True, YELLOW)
            screen.blit(res_surf, (WIDTH//2 - res_surf.get_width()//2, HEIGHT//2 - 80))
            
            hint_text = font.render("Tap Screen or Press 'ESC' to Play Again", True, WHITE)
            screen.blit(hint_text, (WIDTH//2 - hint_text.get_width()//2, HEIGHT//2 + 20))
            
            if keys[pygame.K_ESCAPE]:
                pygame.quit()
                sys.exit()

        p1_ui = font.render(f"P1 Score: {p1.score}", True, BLUE)
        p2_ui = font.render(f"P2 Score: {p2.score}", True, RED)
        count_ui = font.render(f"Target: {target_count}/{MAX_TARGETS}", True, WHITE)
        
        screen.blit(p1_ui, (40, 20))
        screen.blit(p2_ui, (WIDTH - 250, 20))
        screen.blit(count_ui, (WIDTH//2 - 100, 20))

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(main())