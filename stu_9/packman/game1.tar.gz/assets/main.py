import pygame
import random
import math
import sys
import asyncio

# 初期化
pygame.init()

# --- 定数設定 ---
TILE_SIZE = 30
MAZE_MAP = [
    "WWWWWWWWWWWWWWWWWWWWWWWWW",
    "WP......................W",
    "W.WWWW.WWWW.W.WWWW.WWWW.W",
    "W.W..W.W..W.W.W..W.W..W.W",
    "W.WWWW.WWWW.W.WWWW.WWWW.W",
    "W.......................W",
    "W.WWWW.W.WWWWWWW.W.WWWW.W",
    "W..L...W....W....W...L..W",
    "WWWWWW.WWWW W WWWW.WWWWWW",
    ".......W....S....W.......",
    "WWWWWW.W W.....W W.WWWWWW",
    "W........W..L..W........W",
    "WWWWWW.W WWWWWWW W.WWWWWW",
    ".......W....L....W.......",
    "WWWWWW.W WWWWWWW W.WWWWWW",
    "W.......................W",
    "W.WWWW.WWWW.W.WWWW.WWWW.W",
    "W.W..W.W..W.W.W..W.W..W.W",
    "W.WWWW.WWWW.W.WWWW.WWWW.W",
    "W.......................W",
    "WWWWWWWWWWWWWWWWWWWWWWWWW"
]

MAP_WIDTH = len(MAZE_MAP[0])
MAP_HEIGHT = len(MAZE_MAP)

# 画面拡張
UI_HEIGHT = 160
WIDTH = MAP_WIDTH * TILE_SIZE    
HEIGHT = MAP_HEIGHT * TILE_SIZE + UI_HEIGHT  

# 色定義
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
RED = (255, 0, 0)
PINK = (255, 182, 193)
GREEN = (0, 255, 0)
WALL_COLOR = (20, 20, 150)
PAD_BG_COLOR = (40, 40, 40)
PAD_BTN_COLOR = (80, 80, 80)

# 画面とクロックの設定
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pacman Clone for iPad & Web")
clock = pygame.time.Clock()

# --- フォント設定 ---
def get_safe_font(size):
    try:
        return pygame.font.SysFont("arial", size)
    except:
        return pygame.font.Font(None, size)

font = get_safe_font(60)
small_font = get_safe_font(30)

# --- iPad用 バーチャル十字キーの配置 ---
PAD_SIZE = 50 
pad_center_x = WIDTH // 2
pad_center_y = HEIGHT - 80

rect_up    = pygame.Rect(pad_center_x - PAD_SIZE//2, pad_center_y - PAD_SIZE*1.4, PAD_SIZE, PAD_SIZE)
rect_down  = pygame.Rect(pad_center_x - PAD_SIZE//2, pad_center_y + PAD_SIZE*0.4, PAD_SIZE, PAD_SIZE)
rect_left  = pygame.Rect(pad_center_x - PAD_SIZE*1.4, pad_center_y - PAD_SIZE//2, PAD_SIZE, PAD_SIZE)
rect_right = pygame.Rect(pad_center_x + PAD_SIZE*0.4, pad_center_y - PAD_SIZE//2, PAD_SIZE, PAD_SIZE)

rect_retry = pygame.Rect(20, HEIGHT - 70, 180, 50)

# --- 迷路の解析 ---
walls = []
dots = []
player_start_pos = (TILE_SIZE + TILE_SIZE//2, TILE_SIZE + TILE_SIZE//2)
enemy_spawn_points_s = []
enemy_spawn_points_l = []

for r_idx, row in enumerate(MAZE_MAP):
    for c_idx, val in enumerate(row):
        x = c_idx * TILE_SIZE
        y = r_idx * TILE_SIZE
        if val == "W":
            walls.append(pygame.Rect(x, y, TILE_SIZE, TILE_SIZE))
        elif val == ".":
            dots.append(pygame.Rect(x + TILE_SIZE//2 - 2, y + TILE_SIZE//2 - 2, 4, 4))
        elif val == "P":
            player_start_pos = (x + TILE_SIZE//2, y + TILE_SIZE//2)
        elif val == "S":
            enemy_spawn_points_s.append((x + TILE_SIZE//2, y + TILE_SIZE//2))
        elif val == "L":
            enemy_spawn_points_l.append((x + TILE_SIZE//2, y + TILE_SIZE//2))

# キャラクタクラスの定義
class Player:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.speed = 3
        self.dir_x = 1  
        self.dir_y = 0
        self.next_dir_x = 0
        self.next_dir_y = 0
        self.radius = 12
        self.lives = 3

    def reset_position(self):
        self.x, self.y = player_start_pos
        self.dir_x, self.dir_y = 1, 0 
        self.next_dir_x, self.next_dir_y = 0, 0

    def move(self):
        # 進行方向または先行入力がある場合、現在いるタイルの中心に近づいたら方向転換
        # 判定を少し甘くして(誤差5ピクセル以内)、確実に曲がれるように修正
        current_tile_cx = (int(self.x) // TILE_SIZE) * TILE_SIZE + TILE_SIZE // 2
        current_tile_cy = (int(self.y) // TILE_SIZE) * TILE_SIZE + TILE_SIZE // 2

        if abs(self.x - current_tile_cx) <= 4 and abs(self.y - current_tile_cy) <= 4:
            # 先行入力のチェック
            if self.next_dir_x != 0 or self.next_dir_y != 0:
                test_rect = pygame.Rect(current_tile_cx - self.radius, current_tile_cy - self.radius, self.radius*2, self.radius*2)
                test_rect.x += self.next_dir_x * self.speed
                test_rect.y += self.next_dir_y * self.speed
                hit = False
                for wall in walls:
                    if test_rect.colliderect(wall):
                        hit = True
                        break
                if not hit:
                    self.x = current_tile_cx
                    self.y = current_tile_cy
                    self.dir_x = self.next_dir_x
                    self.dir_y = self.next_dir_y
                    self.next_dir_x = 0
                    self.next_dir_y = 0

        # 次の位置の衝突予測
        next_rect = pygame.Rect(self.x - self.radius, self.y - self.radius, self.radius*2, self.radius*2)
        next_rect.x += self.dir_x * self.speed
        next_rect.y += self.dir_y * self.speed

        hit = False
        for wall in walls:
            if next_rect.colliderect(wall):
                hit = True
                break
        
        if not hit:
            self.x += self.dir_x * self.speed
            self.y += self.dir_y * self.speed
        else:
            # 修正点: 壁にぶつかって止まった際、即座にマスの中央座標へジャストフィットさせる
            self.x = current_tile_cx
            self.y = current_tile_cy
            self.dir_x = 0
            self.dir_y = 0
            
            # 壁に突っ込んで止まっている状態でも、次の入力があれば即座にそっちを向く
            if self.next_dir_x != 0 or self.next_dir_y != 0:
                test_rect = pygame.Rect(self.x - self.radius, self.y - self.radius, self.radius*2, self.radius*2)
                test_rect.x += self.next_dir_x * self.speed
                test_rect.y += self.next_dir_y * self.speed
                hit_next = False
                for wall in walls:
                    if test_rect.colliderect(wall):
                        hit_next = True
                        break
                if not hit_next:
                    self.dir_x = self.next_dir_x
                    self.dir_y = self.next_dir_y
                    self.next_dir_x = 0
                    self.next_dir_y = 0

        if self.x < 0: self.x = WIDTH
        elif self.x > WIDTH: self.x = 0

    def draw(self, surf):
        pygame.draw.circle(surf, YELLOW, (int(self.x), int(self.y)), self.radius)

class Enemy:
    def __init__(self, x, y, type):
        self.x = x
        self.y = y
        self.type = type  
        self.speed = 2
        self.dir_x = 0
        self.dir_y = 0
        self.radius = 12
        self.color = RED if type == 'S' else PINK

    def move(self, p_x, p_y):
        if (int(self.x) % TILE_SIZE == TILE_SIZE // 2) and (int(self.y) % TILE_SIZE == TILE_SIZE // 2):
            valid_dirs = []
            directions = [(0, -1), (0, 1), (-1, 0), (1, 0)]
            
            for dx, dy in directions:
                if dx == -self.dir_x and dy == -self.dir_y and self.dir_x != 0 and self.dir_y != 0:
                    continue
                test_rect = pygame.Rect(self.x - self.radius, self.y - self.radius, self.radius*2, self.radius*2)
                test_rect.x += dx * TILE_SIZE
                test_rect.y += dy * TILE_SIZE
                hit = False
                for wall in walls:
                    if test_rect.colliderect(wall):
                        hit = True
                        break
                if not hit:
                    valid_dirs.append((dx, dy))

            if valid_dirs:
                if self.type == 'S': 
                    best_dir = valid_dirs[0]
                    min_dist = float('inf')
                    for dx, dy in valid_dirs:
                        nx = self.x + dx * TILE_SIZE
                        ny = self.y + dy * TILE_SIZE
                        dist = math.hypot(nx - p_x, ny - p_y)
                        if dist < min_dist:
                            min_dist = dist
                            best_dir = (dx, dy)
                    self.dir_x, self.dir_y = best_dir
                else: 
                    if random.random() < 0.2 or (self.dir_x == 0 and self.dir_y == 0):
                        self.dir_x, self.dir_y = random.choice(valid_dirs)
            else:
                self.dir_x = -self.dir_x
                self.dir_y = -self.dir_y

        self.x += self.dir_x * self.speed
        self.y += self.dir_y * self.speed

        if self.x < 0: self.x = WIDTH
        elif self.x > WIDTH: self.x = 0

    def draw(self, surf):
        pygame.draw.circle(surf, self.color, (int(self.x), int(self.y)), self.radius)

def draw_heart(surf, x, y, size):
    points = [
        (x, y + size // 4),
        (x - size // 2, y - size // 4),
        (x - size // 4, y - size // 2),
        (x, y - size // 4),
        (x + size // 4, y - size // 2),
        (x + size // 2, y - size // 4)
    ]
    pygame.draw.polygon(surf, RED, points)

player = Player(player_start_pos[0], player_start_pos[1])
enemies = []

def init_game():
    global dots, score, game_over, game_clear
    score = 0
    game_over = False
    game_clear = False
    player.lives = 3
    player.reset_position()
    
    dots = []
    for r_idx, row in enumerate(MAZE_MAP):
        for c_idx, val in enumerate(row):
            if val == "." or val == "P": 
                dots.append(pygame.Rect(c_idx*TILE_SIZE + TILE_SIZE//2 - 2, r_idx*TILE_SIZE + TILE_SIZE//2 - 2, 4, 4))
                
    enemies.clear()
    for pt in enemy_spawn_points_s:
        enemies.append(Enemy(pt[0], pt[1], 'S'))
    for pt in enemy_spawn_points_l:
        enemies.append(Enemy(pt[0], pt[1], 'L'))

init_game()

# --- メインループ関数 ---
async def main():
    global score, game_over, game_clear

    running = True
    while running:
        clock.tick(60)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                
            elif event.type == pygame.KEYDOWN:
                if game_over or game_clear:
                    if event.key == pygame.K_r:
                        init_game()
                else:
                    if event.key in [pygame.K_UP, pygame.K_w]:
                        player.next_dir_x, player.next_dir_y = 0, -1
                    elif event.key in [pygame.K_DOWN, pygame.K_s]:
                        player.next_dir_x, player.next_dir_y = 0, 1
                    elif event.key in [pygame.K_LEFT, pygame.K_a]:
                        player.next_dir_x, player.next_dir_y = -1, 0
                    elif event.key in [pygame.K_RIGHT, pygame.K_d]:
                        player.next_dir_x, player.next_dir_y = 1, 0

            elif event.type == pygame.FINGERDOWN:
                fx, fy = event.x * WIDTH, event.y * HEIGHT
                if not (game_over or game_clear):
                    if rect_up.collidepoint(fx, fy): player.next_dir_x, player.next_dir_y = 0, -1
                    elif rect_down.collidepoint(fx, fy): player.next_dir_x, player.next_dir_y = 0, 1
                    elif rect_left.collidepoint(fx, fy): player.next_dir_x, player.next_dir_y = -1, 0
                    elif rect_right.collidepoint(fx, fy): player.next_dir_x, player.next_dir_y = 1, 0
                else:
                    if rect_retry.collidepoint(fx, fy): init_game()

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                pos = event.pos
                if game_over or game_clear:
                    if rect_retry.collidepoint(pos):
                        init_game()
                else:
                    if rect_up.collidepoint(pos): player.next_dir_x, player.next_dir_y = 0, -1
                    elif rect_down.collidepoint(pos): player.next_dir_x, player.next_dir_y = 0, 1
                    elif rect_left.collidepoint(pos): player.next_dir_x, player.next_dir_y = -1, 0
                    elif rect_right.collidepoint(pos): player.next_dir_x, player.next_dir_y = 1, 0

        if not game_over and not game_clear:
            player.move()

            p_rect = pygame.Rect(player.x - player.radius, player.y - player.radius, player.radius*2, player.radius*2)
            for dot in dots[:]:
                if p_rect.colliderect(dot):
                    dots.remove(dot)
                    score += 10

            if not dots:
                game_clear = True

            for enemy in enemies:
                enemy.move(player.x, player.y)
                e_rect = pygame.Rect(enemy.x - enemy.radius, enemy.y - enemy.radius, enemy.radius*2, enemy.radius*2)
                if p_rect.colliderect(e_rect):
                    player.lives -= 1
                    if player.lives <= 0:
                        game_over = True
                    else:
                        player.reset_position()
                        for e in enemies:
                            if e.type == 'S' and enemy_spawn_points_s:
                                e.x, e.y = enemy_spawn_points_s[0]
                            elif e.type == 'L' and enemy_spawn_points_l:
                                e.x, e.y = random.choice(enemy_spawn_points_l)
                            e.dir_x, e.dir_y = 0, 0

        screen.fill(BLACK)

        for wall in walls:
            pygame.draw.rect(screen, WALL_COLOR, wall, border_radius=4)
        for dot in dots:
            pygame.draw.circle(screen, WHITE, dot.center, 3)

        if not game_over:
            player.draw(screen)
        for enemy in enemies:
            enemy.draw(screen)

        # --- UI & バーチャル十字キー ---
        ui_rect = pygame.Rect(0, HEIGHT - UI_HEIGHT, WIDTH, UI_HEIGHT)
        pygame.draw.rect(screen, PAD_BG_COLOR, ui_rect)
        pygame.draw.line(screen, WHITE, (0, HEIGHT - UI_HEIGHT), (WIDTH, HEIGHT - UI_HEIGHT), 2)

        score_text = small_font.render(f"SCORE: {score}", True, WHITE)
        screen.blit(score_text, (20, HEIGHT - UI_HEIGHT + 15))

        for i in range(player.lives):
            draw_heart(screen, WIDTH - 40 - i * 40, HEIGHT - UI_HEIGHT + 30, 24)

        pygame.draw.rect(screen, PAD_BTN_COLOR, rect_up, border_radius=6)
        pygame.draw.rect(screen, PAD_BTN_COLOR, rect_down, border_radius=6)
        pygame.draw.rect(screen, PAD_BTN_COLOR, rect_left, border_radius=6)
        pygame.draw.rect(screen, PAD_BTN_COLOR, rect_right, border_radius=6)

        u_surf = small_font.render("U", True, WHITE)
        d_surf = small_font.render("D", True, WHITE)
        l_surf = small_font.render("L", True, WHITE)
        r_surf = small_font.render("R", True, WHITE)
        screen.blit(u_surf, u_surf.get_rect(center=rect_up.center))
        screen.blit(d_surf, d_surf.get_rect(center=rect_down.center))
        screen.blit(l_surf, l_surf.get_rect(center=rect_left.center))
        screen.blit(r_surf, r_surf.get_rect(center=rect_right.center))

        if game_over:
            text = font.render("GAME OVER", True, RED)
            screen.blit(text, (WIDTH//2 - text.get_width()//2, MAP_HEIGHT * TILE_SIZE // 2 - 40))
            
            pygame.draw.rect(screen, RED, rect_retry, border_radius=8)
            retry_text = small_font.render("RETRY", True, WHITE)
            screen.blit(retry_text, (rect_retry.centerx - retry_text.get_width()//2, rect_retry.centery - retry_text.get_height()//2))

        elif game_clear:
            text = font.render("GAME CLEAR!", True, GREEN)
            screen.blit(text, (WIDTH//2 - text.get_width()//2, MAP_HEIGHT * TILE_SIZE // 2 - 40))
            
            pygame.draw.rect(screen, GREEN, rect_retry, border_radius=8)
            retry_text = small_font.render("PLAY AGAIN", True, BLACK)
            screen.blit(retry_text, (rect_retry.centerx - retry_text.get_width()//2, rect_retry.centery - retry_text.get_height()//2))

        pygame.display.flip()
        await asyncio.sleep(0)  

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    asyncio.run(main())